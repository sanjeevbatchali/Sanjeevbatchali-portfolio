import ExcelJS from "exceljs";
import JSZip from "jszip";
import { describe, expect, it } from "vitest";

import { runModel } from "./engine";
import { DEFAULT_INPUTS, type ModelInputs } from "./types";
import { buildWorkbook } from "./workbook";

const cases: Array<Partial<ModelInputs>> = [
  {},
  { capacityMw: 50 },
  { targetDscr: 1.45 },
  { debtTenor: 20 },
  { generationBasis: "P90" },
  { carbonRevenue: false },
  { carbonDebtSizing: true },
  { capacityMw: 1, ppaEscalationPct: 0, omEscalationPct: 0, landEscalationPct: 0, carbonPriceEscalationPct: 0 },
];

describe("solar project finance engine", () => {
  it("reproduces the audited default case", () => {
    const model = runModel(DEFAULT_INPUTS);
    const yearOne = model.years[1];

    expect(yearOne.generation).toBeCloseTo(190_000, 6);
    expect(yearOne.ppaRevenue).toBeCloseTo(12_350_000, 2);
    expect(yearOne.opex).toBeCloseTo(2_000_000, 2);
    expect(yearOne.cfadsLender).toBeCloseTo(10_346_000, 2);
    expect(yearOne.debtService).toBeCloseTo(7_958_461.54, 2);
    expect(model.years[0].idc).toBeCloseTo(2_769_127.22, 2);
    expect(model.totalUses).toBeCloseTo(112_969_127.22, 2);
    expect(model.seniorDebt).toBeCloseTo(92_304_240.61, 2);
    expect(model.equityFunding).toBeCloseTo(20_664_886.61, 2);
    expect(yearOne.depreciation).toBeCloseTo(3_221_975.06, 2);
    expect(yearOne.profitAfterTax).toBeCloseTo(1_779_770.5, 2);
    expect(model.minDscr).toBeCloseTo(1.3, 10);
    expect(model.years[25].debtClosing).toBeCloseTo(0, 2);
    expect(model.projectIrrExcludingIdc).toBeCloseTo(0.080561, 6);
    expect(model.equityIrr).toBeCloseTo(0.124949, 6);
    expect(model.equityNpv).toBeCloseTo(8_572_346.55, 2);
    expect(model.projectNpvAtEquityCost).toBeCloseTo(-9_025_815, 2);
  });

  it.each(cases)("produces finite, internally consistent outputs for case %#", (overrides) => {
    const model = runModel({ ...DEFAULT_INPUTS, ...overrides });
    expect(model.years).toHaveLength(36);
    expect(Number.isFinite(model.seniorDebt)).toBe(true);
    expect(Number.isFinite(model.totalUses)).toBe(true);
    expect(model.years.every((year) => Object.values(year).every((value) => value === null || Number.isFinite(value)))).toBe(true);
    expect(model.seniorDebt + model.equityFunding).toBeCloseTo(model.totalUses, 2);
  });
});

describe("generated workbook", () => {
  it("is a five-sheet, formula-linked workbook that recalculates on open", async () => {
    const bytes = await buildWorkbook(DEFAULT_INPUTS);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes);

    expect(workbook.worksheets.map((sheet) => sheet.name)).toEqual([
      "Cover",
      "Control Room",
      "Schedules",
      "FS",
      "Output",
    ]);
    const archive = await JSZip.loadAsync(bytes);
    const workbookXml = await archive.file("xl/workbook.xml")?.async("string");
    expect(workbookXml).toContain('fullCalcOnLoad="1"');

    let formulaCount = 0;
    for (const sheet of workbook.worksheets) {
      sheet.eachRow((row) => {
        row.eachCell((cell) => {
          if (cell.type === ExcelJS.ValueType.Formula) {
            formulaCount += 1;
            const formula = String((cell.value as { formula: string }).formula);
            expect(formula).not.toMatch(/#REF!|#VALUE!|#DIV\/0!|#NAME\?|#N\/A|#NUM!/);
          }
        });
      });
    }
    expect(formulaCount).toBeGreaterThan(3_000);

    for (const name of ["Schedules", "FS"]) {
      const sheet = workbook.getWorksheet(name);
      expect(sheet).toBeDefined();
      sheet?.eachRow((row, rowNumber) => {
        row.eachCell((cell, columnNumber) => {
          if (columnNumber >= 5 && columnNumber <= 40 && typeof cell.value === "number") {
            expect(name === "Schedules" && rowNumber === 6).toBe(true);
          }
        });
      });
    }
    expect(workbookXml).not.toContain("<definedNames>");
  });
});