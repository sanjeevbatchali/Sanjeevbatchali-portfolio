import {
  DEFAULT_INPUTS,
  type ModelInputs,
  type ModelResults,
  type ModelValidation,
  type YearData,
} from "./types";

const YEARS = 36;
const EPSILON = 1e-9;

const rate = (pct: number) => pct / 100;

export function validateInputs(inputs: ModelInputs): ModelValidation {
  const errors: ModelValidation["errors"] = {};
  const requiredPositive: Array<[keyof ModelInputs, string]> = [
    ["capacityMw", "Installed capacity must be greater than 0 MW."],
    ["epcCostPerKw", "EPC cost must be greater than 0."],
    ["ppaTariff", "PPA tariff must be greater than 0."],
  ];

  for (const [key, message] of requiredPositive) {
    if (typeof inputs[key] !== "number" || inputs[key] <= 0) errors[key] = message;
  }

  const ranges: Array<[keyof ModelInputs, number, number, string]> = [
    ["yieldHours", 500, 3000, "Production yield must be between 500 and 3,000 hours."],
    ["degradationPct", 0, 3, "Annual degradation must be between 0% and 3%."],
    ["operatingLife", 5, 40, "Operating life must be between 5 and 40 years."],
    ["debtTenor", 1, 40, "Senior debt tenor must be between 1 and 40 years."],
    ["interestRatePct", 0, 25, "Interest rate must be between 0% and 25%."],
    ["targetDscr", 1, 3, "Target DSCR must be between 1.00x and 3.00x."],
    ["costOfEquityPct", 0, 40, "Cost of equity must be between 0% and 40%."],
  ];
  for (const [key, min, max, message] of ranges) {
    const value = inputs[key];
    if (typeof value !== "number" || value < min || value > max) errors[key] = message;
  }

  const nonNegative: Array<[keyof ModelInputs, string]> = [
    ["softCostPerKw", "Financing and soft cost cannot be negative."],
    ["omCostPerKwYear", "O&M cost cannot be negative."],
    ["landLeasePerYear", "Land lease cannot be negative."],
    ["ppaEscalationPct", "PPA escalation cannot be negative."],
    ["omEscalationPct", "O&M escalation cannot be negative."],
    ["landEscalationPct", "Land lease escalation cannot be negative."],
    ["workingCapitalPct", "Working capital requirement cannot be negative."],
    ["taxRatePct", "Corporate tax rate cannot be negative."],
    ["idcDrawPct", "Average construction debt drawn cannot be negative."],
    ["idcInterestRatePct", "IDC interest rate cannot be negative."],
    ["energyUncertaintyPct", "Energy uncertainty cannot be negative."],
    ["gridEmissionFactor", "Grid emission factor cannot be negative."],
    ["carbonPrice", "Carbon credit price cannot be negative."],
    ["carbonPriceEscalationPct", "Carbon price escalation cannot be negative."],
    ["zScore", "The z score cannot be negative."],
  ];
  for (const [key, message] of nonNegative) {
    if (typeof inputs[key] !== "number" || inputs[key] < 0) errors[key] = message;
  }

  if (inputs.operatingLife < 1 || inputs.debtTenor > inputs.operatingLife) {
    errors.crossField = "Debt tenor cannot exceed operating life.";
  }
  if (inputs.ppaTerm < 1 || inputs.ppaTerm > inputs.operatingLife) {
    errors.crossField = "PPA term cannot exceed operating life.";
  }
  if (!inputs.projectName.trim()) errors.projectName = "Project name is required.";

  return { errors, isValid: Object.keys(errors).length === 0 };
}

function npv(discountRate: number, cashFlows: number[]): number {
  return cashFlows.reduce((sum, cashFlow, index) => sum + cashFlow / (1 + discountRate) ** index, 0);
}

export function irr(cashFlows: number[]): number | null {
  if (cashFlows.length < 2) return null;
  const hasPositive = cashFlows.some((value) => value > EPSILON);
  const hasNegative = cashFlows.some((value) => value < -EPSILON);
  if (!hasPositive || !hasNegative) return null;

  let low = -0.9999;
  let high = 1;
  let lowValue = npv(low, cashFlows);
  let highValue = npv(high, cashFlows);
  let attempts = 0;
  while (lowValue * highValue > 0 && attempts < 20) {
    high *= 2;
    highValue = npv(high, cashFlows);
    attempts += 1;
  }
  if (lowValue * highValue > 0) return null;

  for (let i = 0; i < 120; i += 1) {
    const mid = (low + high) / 2;
    const midValue = npv(mid, cashFlows);
    if (Math.abs(midValue) < 1e-7) return mid;
    if (lowValue * midValue <= 0) {
      high = mid;
      highValue = midValue;
    } else {
      low = mid;
      lowValue = midValue;
    }
  }
  return (low + high) / 2;
}

export function runModel(input: ModelInputs = DEFAULT_INPUTS): ModelResults {
  const inputs = { ...DEFAULT_INPUTS, ...input };
  const validation = validateInputs(inputs);
  if (!validation.isValid) {
    return {
      inputs,
      years: [],
      seniorDebt: 0,
      equityFunding: 0,
      totalUses: 0,
      gearing: 0,
      minDscr: null,
      averageDscr: null,
      maxDscr: null,
      debtRepaidYear: null,
      totalInterest: 0,
      projectIrrExcludingIdc: null,
      projectIrrIncludingIdc: null,
      equityIrr: null,
      projectNpvAtEquityCost: null,
      projectNpvAtWacc: null,
      equityNpv: null,
      warnings: Object.values(validation.errors).filter(Boolean) as string[],
    };
  }

  const capacityKw = inputs.capacityMw * 1000;
  const interestRate = rate(inputs.interestRatePct);
  const idcRate = rate(inputs.idcInterestRatePct);
  const taxRate = rate(inputs.taxRatePct);
  const p50 = 1;
  const p90 = 1 - inputs.zScore * rate(inputs.energyUncertaintyPct);
  const exceedanceFactor = inputs.generationBasis === "P90" ? p90 : p50;
  const years = Array.from({ length: YEARS }, (_, year) => year);

  const base = years.map<Partial<YearData>>((year) => {
    const operating = year > 0 && year <= inputs.operatingLife ? 1 : 0;
    const degradationFactor = operating ? (1 - rate(inputs.degradationPct)) ** (year - 1) : 0;
    const generation = operating ? inputs.capacityMw * degradationFactor * inputs.yieldHours * exceedanceFactor : 0;
    const tariff =
      operating && year <= inputs.ppaTerm
        ? inputs.ppaTariff * (1 + rate(inputs.ppaEscalationPct)) ** (year - 1)
        : 0;
    const ppaRevenue = generation * tariff;
    const emissionFactor = operating ? inputs.gridEmissionFactor : 0;
    const carbonVolume = generation * emissionFactor;
    const carbonPrice =
      operating ? inputs.carbonPrice * (1 + rate(inputs.carbonPriceEscalationPct)) ** (year - 1) : 0;
    const carbonRevenue = carbonVolume * carbonPrice * (inputs.carbonRevenue ? 1 : 0);
    const totalRevenue = ppaRevenue + carbonRevenue;
    const omRate = operating ? inputs.omCostPerKwYear * (1 + rate(inputs.omEscalationPct)) ** (year - 1) : 0;
    const om = omRate * (operating ? capacityKw : 0);
    const land = operating ? inputs.landLeasePerYear * (1 + rate(inputs.landEscalationPct)) ** (year - 1) : 0;
    const opex = om + land;
    const ebitda = totalRevenue - opex;
    return {
      year,
      operating,
      generation,
      tariff,
      ppaRevenue,
      carbonRevenue,
      totalRevenue,
      omRate,
      om,
      land,
      opex,
      ebitda,
    };
  });

  for (let year = 0; year < YEARS; year += 1) {
    const nextOpex = year < YEARS - 1 ? Number(base[year + 1].opex ?? 0) : 0;
    base[year].workingCapitalBalance = year < YEARS - 1 ? rate(inputs.workingCapitalPct) * nextOpex : 0;
    base[year].workingCapitalMovement =
      year === 0
        ? 0
        : -((base[year].workingCapitalBalance ?? 0) - (base[year - 1].workingCapitalBalance ?? 0));
    base[year].epcCost = year === 0 ? inputs.epcCostPerKw * capacityKw : 0;
    base[year].softCost = year === 0 ? inputs.softCostPerKw * capacityKw : 0;
    base[year].capex = (base[year].epcCost ?? 0) + (base[year].softCost ?? 0) + (base[year].idc ?? 0);
    base[year].workingCapitalFunding = year === 0 ? base[year].workingCapitalBalance : 0;
    base[year].uses = (base[year].capex ?? 0) + (base[year].workingCapitalFunding ?? 0);
    base[year].cfadsForSizing =
      (base[year].generation ?? 0) * (base[year].tariff ?? 0) +
      (inputs.carbonDebtSizing ? base[year].carbonRevenue ?? 0 : 0) -
      (base[year].opex ?? 0) +
      (base[year].workingCapitalMovement ?? 0);
    base[year].cfadsLender =
      (base[year].ppaRevenue ?? 0) +
      (inputs.carbonDebtSizing ? base[year].carbonRevenue ?? 0 : 0) -
      (base[year].opex ?? 0) +
      (base[year].workingCapitalMovement ?? 0);
    base[year].cfadsTotal =
      (base[year].totalRevenue ?? 0) - (base[year].opex ?? 0) + (base[year].workingCapitalMovement ?? 0);
    base[year].targetDebtService =
      year >= 1 && year <= inputs.debtTenor ? Math.max(0, (base[year].cfadsForSizing ?? 0) / inputs.targetDscr) : 0;
  }

  const debtServiceStream = base.slice(1).map((row) => Number(row.targetDebtService ?? 0));
  const seniorDebt = npv(interestRate, [0, ...debtServiceStream]);
  const idc = seniorDebt * idcRate * rate(inputs.idcDrawPct);
  base[0].idc = idc;
  base[0].capex = (base[0].epcCost ?? 0) + (base[0].softCost ?? 0) + idc;
  base[0].uses = (base[0].capex ?? 0) + (base[0].workingCapitalFunding ?? 0);
  for (let year = 1; year < YEARS; year += 1) {
    base[year].idc = 0;
    base[year].capex = (base[year].epcCost ?? 0) + (base[year].softCost ?? 0);
    base[year].uses = (base[year].capex ?? 0) + (base[year].workingCapitalFunding ?? 0);
  }

  let debtClosing = 0;
  let grossBookClosing = 0;
  let accumulatedDepClosingValue = 0;
  let shareCapital = 0;
  let retainedEarnings = 0;
  let closingCash = 0;
  const completeYears: YearData[] = base.map((row, year) => {
    const grossBookValueOpening = year === 0 ? 0 : grossBookClosing;
    const grossBookValueAddition = Number(row.capex ?? 0);
    const grossBookValueClosing = grossBookValueOpening + grossBookValueAddition;
    grossBookClosing = grossBookValueClosing;
    const accumulatedDepOpening = year === 0 ? 0 : accumulatedDepClosingValue;
    const depreciation =
      row.operating && year <= inputs.depreciableLife ? grossBookValueClosing / inputs.depreciableLife : 0;
    const accumulatedDepClosing = accumulatedDepOpening + depreciation;
    accumulatedDepClosingValue = accumulatedDepClosing;
    const netBookValue = grossBookValueClosing - accumulatedDepClosing;
    const debtOpening = year === 0 ? 0 : year === 1 ? seniorDebt : debtClosing;
    const debtInterest = debtOpening * interestRate;
    const scheduledService = Number(row.targetDebtService ?? 0);
    const debtPrincipal = scheduledService > debtInterest ? Math.min(debtOpening, scheduledService - debtInterest) : 0;
    const debtService = debtInterest + debtPrincipal;
    debtClosing = Math.max(0, debtOpening - debtPrincipal);
    const dscr = scheduledService > EPSILON && debtOpening > EPSILON ? (row.cfadsLender ?? 0) / scheduledService : null;
    const debtDraw = year === 0 ? seniorDebt : 0;
    const equityContribution = (row.uses ?? 0) - debtDraw;
    const pbt = (row.ebitda ?? 0) - depreciation - debtInterest;
    const tax = -pbt * taxRate;
    const profitAfterTax = pbt + tax;
    shareCapital = year === 0 ? equityContribution : shareCapital + equityContribution;
    const cfo = profitAfterTax + depreciation + debtInterest;
    const cfi = -(row.capex ?? 0);
    const cfade = (row.cfadsTotal ?? 0) - debtService;
    retainedEarnings =
      year === 0 ? profitAfterTax : retainedEarnings + profitAfterTax - cfade;
    const totalEquity = shareCapital + retainedEarnings;
    const cff = debtDraw - debtPrincipal - debtInterest + equityContribution - cfade;
    const netCashMovement = cfo + cfi + cff;
    const openingCash = year === 0 ? 0 : closingCash;
    closingCash = openingCash + netCashMovement;
    const fcff = (row.ebitda ?? 0) + tax + Number(row.workingCapitalMovement ?? 0) -
      Number(row.workingCapitalFunding ?? 0) - (row.capex ?? 0);
    const projectCashFlowExcludingIdc = fcff + Number(row.idc ?? 0);
    const fcfe = fcff - debtInterest + debtDraw - debtPrincipal;

    return {
      year,
      operating: Number(row.operating ?? 0),
      generation: Number(row.generation ?? 0),
      tariff: Number(row.tariff ?? 0),
      ppaRevenue: Number(row.ppaRevenue ?? 0),
      carbonRevenue: Number(row.carbonRevenue ?? 0),
      totalRevenue: Number(row.totalRevenue ?? 0),
      omRate: Number(row.omRate ?? 0),
      om: Number(row.om ?? 0),
      land: Number(row.land ?? 0),
      opex: Number(row.opex ?? 0),
      ebitda: Number(row.ebitda ?? 0),
      workingCapitalBalance: Number(row.workingCapitalBalance ?? 0),
      workingCapitalMovement: Number(row.workingCapitalMovement ?? 0),
      epcCost: Number(row.epcCost ?? 0),
      softCost: Number(row.softCost ?? 0),
      idc: Number(row.idc ?? 0),
      capex: Number(row.capex ?? 0),
      workingCapitalFunding: Number(row.workingCapitalFunding ?? 0),
      uses: Number(row.uses ?? 0),
      debtDraw,
      equityContribution,
      grossBookValueOpening,
      grossBookValueAddition,
      grossBookValueClosing,
      accumulatedDepOpening,
      depreciation,
      accumulatedDepClosing,
      netBookValue,
      cfadsForSizing: Number(row.cfadsForSizing ?? 0),
      cfadsLender: Number(row.cfadsLender ?? 0),
      cfadsTotal: Number(row.cfadsTotal ?? 0),
      targetDebtService: scheduledService,
      debtOpening,
      debtInterest,
      debtPrincipal,
      debtClosing,
      debtService,
      dscr,
      cashAvailableForDistribution: cfade,
      pbt,
      tax,
      profitAfterTax,
      shareCapital,
      retainedEarnings,
      totalEquity,
      closingCash,
      cfo,
      cfi,
      cff,
      netCashMovement,
      fcff,
      projectCashFlowExcludingIdc,
      fcfe,
    };
  });

  const operatingYears = completeYears.filter((row) => row.year >= 1 && row.year <= inputs.operatingLife);
  const dscrs = operatingYears.map((row) => row.dscr).filter((value): value is number => value !== null);
  const projectCashFlowIncludingIdc = completeYears.map((row) => row.fcff);
  const projectCashFlowExcludingIdc = completeYears.map((row) => row.projectCashFlowExcludingIdc);
  const equityCashFlow = completeYears.map((row) => row.fcfe);
  const equityFunding = completeYears[0]?.equityContribution ?? 0;
  const totalUses = completeYears[0]?.uses ?? 0;
  const projectNpvAtEquityCost = npv(rate(inputs.costOfEquityPct), projectCashFlowExcludingIdc);
  const equityNpv = npv(rate(inputs.costOfEquityPct), equityCashFlow);
  const wacc = totalUses > 0
    ? (seniorDebt / totalUses) * interestRate + (equityFunding / totalUses) * rate(inputs.costOfEquityPct)
    : rate(inputs.costOfEquityPct);
  const projectNpvAtWacc = npv(wacc, projectCashFlowExcludingIdc);
  const debtRepaidYear = completeYears.find((row) => row.year >= 1 && row.debtClosing <= 0.01)?.year ?? null;
  const warnings: string[] = [];
  if (seniorDebt <= EPSILON) warnings.push("These inputs do not support a senior debt facility.");
  if (operatingYears.some((row) => row.cfadsForSizing < 0)) {
    warnings.push("CFADS turns negative in at least one operating year; debt sizing is floored at zero for that year.");
  }

  return {
    inputs,
    years: completeYears,
    seniorDebt,
    equityFunding,
    totalUses,
    gearing: totalUses > 0 ? seniorDebt / totalUses : 0,
    minDscr: dscrs.length ? Math.min(...dscrs) : null,
    averageDscr: dscrs.length ? dscrs.reduce((sum, value) => sum + value, 0) / dscrs.length : null,
    maxDscr: dscrs.length ? Math.max(...dscrs) : null,
    debtRepaidYear,
    totalInterest: completeYears.reduce((sum, row) => sum + row.debtInterest, 0),
    projectIrrExcludingIdc: irr(projectCashFlowExcludingIdc),
    projectIrrIncludingIdc: irr(projectCashFlowIncludingIdc),
    equityIrr: irr(equityCashFlow),
    projectNpvAtEquityCost,
    projectNpvAtWacc,
    equityNpv,
    warnings,
  };
}