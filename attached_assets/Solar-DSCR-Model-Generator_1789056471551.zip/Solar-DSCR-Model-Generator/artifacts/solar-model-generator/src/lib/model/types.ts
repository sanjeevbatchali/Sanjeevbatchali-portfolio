export type GenerationBasis = "P50" | "P90";

export interface ModelInputs {
  projectName: string;
  capacityMw: number;
  yieldHours: number;
  degradationPct: number;
  operatingLife: number;
  epcCostPerKw: number;
  softCostPerKw: number;
  ppaTariff: number;
  omCostPerKwYear: number;
  landLeasePerYear: number;
  debtTenor: number;
  interestRatePct: number;
  targetDscr: number;
  costOfEquityPct: number;
  ppaEscalationPct: number;
  ppaTerm: number;
  omEscalationPct: number;
  landEscalationPct: number;
  workingCapitalPct: number;
  depreciableLife: number;
  taxRatePct: number;
  idcDrawPct: number;
  idcInterestRatePct: number;
  generationBasis: GenerationBasis;
  energyUncertaintyPct: number;
  carbonRevenue: boolean;
  gridEmissionFactor: number;
  carbonPrice: number;
  carbonPriceEscalationPct: number;
  carbonDebtSizing: boolean;
  zScore: number;
}

export const DEFAULT_INPUTS: ModelInputs = {
  projectName: "Utility-scale solar PV",
  capacityMw: 100,
  yieldHours: 1900,
  degradationPct: 0.5,
  operatingLife: 35,
  epcCostPerKw: 1000,
  softCostPerKw: 100,
  ppaTariff: 65,
  omCostPerKwYear: 10,
  landLeasePerYear: 1_000_000,
  debtTenor: 25,
  interestRatePct: 6,
  targetDscr: 1.3,
  costOfEquityPct: 9,
  ppaEscalationPct: 0,
  ppaTerm: 35,
  omEscalationPct: 2,
  landEscalationPct: 2,
  workingCapitalPct: 10,
  depreciableLife: 35,
  taxRatePct: 0,
  idcDrawPct: 50,
  idcInterestRatePct: 6,
  generationBasis: "P50",
  energyUncertaintyPct: 6.9,
  carbonRevenue: true,
  gridEmissionFactor: 0.4,
  carbonPrice: 2.5,
  carbonPriceEscalationPct: 2,
  carbonDebtSizing: false,
  zScore: 1.2816,
};

export interface YearData {
  year: number;
  operating: number;
  generation: number;
  tariff: number;
  ppaRevenue: number;
  carbonRevenue: number;
  totalRevenue: number;
  omRate: number;
  om: number;
  land: number;
  opex: number;
  ebitda: number;
  workingCapitalBalance: number;
  workingCapitalMovement: number;
  epcCost: number;
  softCost: number;
  idc: number;
  capex: number;
  workingCapitalFunding: number;
  uses: number;
  debtDraw: number;
  equityContribution: number;
  grossBookValueOpening: number;
  grossBookValueAddition: number;
  grossBookValueClosing: number;
  accumulatedDepOpening: number;
  depreciation: number;
  accumulatedDepClosing: number;
  netBookValue: number;
  cfadsForSizing: number;
  cfadsLender: number;
  cfadsTotal: number;
  targetDebtService: number;
  debtOpening: number;
  debtInterest: number;
  debtPrincipal: number;
  debtClosing: number;
  debtService: number;
  dscr: number | null;
  cashAvailableForDistribution: number;
  pbt: number;
  tax: number;
  profitAfterTax: number;
  shareCapital: number;
  retainedEarnings: number;
  totalEquity: number;
  closingCash: number;
  cfo: number;
  cfi: number;
  cff: number;
  netCashMovement: number;
  fcff: number;
  projectCashFlowExcludingIdc: number;
  fcfe: number;
}

export interface ModelResults {
  inputs: ModelInputs;
  years: YearData[];
  seniorDebt: number;
  equityFunding: number;
  totalUses: number;
  gearing: number;
  minDscr: number | null;
  averageDscr: number | null;
  maxDscr: number | null;
  debtRepaidYear: number | null;
  totalInterest: number;
  projectIrrExcludingIdc: number | null;
  projectIrrIncludingIdc: number | null;
  equityIrr: number | null;
  projectNpvAtEquityCost: number | null;
  projectNpvAtWacc: number | null;
  equityNpv: number | null;
  warnings: string[];
}

export interface ModelValidation {
  errors: Partial<Record<keyof ModelInputs | "crossField", string>>;
  isValid: boolean;
}