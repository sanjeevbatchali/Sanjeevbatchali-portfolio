import { useMemo, useState, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Calculator,
  Check,
  ChevronDown,
  Download,
  FileSpreadsheet,
  RotateCcw,
  ShieldCheck,
} from "lucide-react";

import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { runModel, validateInputs } from "@/lib/model/engine";
import { DEFAULT_INPUTS, type ModelInputs, type YearData } from "@/lib/model/types";
import { downloadWorkbook } from "@/lib/model/workbook";

const queryClient = new QueryClient();

type NumericKey = {
  [K in keyof ModelInputs]: ModelInputs[K] extends number ? K : never;
}[keyof ModelInputs];

type FieldDefinition = {
  key: NumericKey;
  label: string;
  suffix: string;
  help?: string;
  step?: number;
};

const basicFields: FieldDefinition[] = [
  { key: "capacityMw", label: "Installed capacity", suffix: "MW", step: 0.1, help: "Nameplate project capacity." },
  { key: "yieldHours", label: "Production yield", suffix: "hours / yr", step: 1, help: "Equivalent full-load hours." },
  { key: "degradationPct", label: "Annual degradation", suffix: "%", step: 0.01 },
  { key: "operatingLife", label: "Operating life", suffix: "years", step: 1 },
  { key: "epcCostPerKw", label: "EPC cost", suffix: "$ / kW", step: 1 },
  { key: "softCostPerKw", label: "Financing & soft cost", suffix: "$ / kW", step: 1 },
  { key: "ppaTariff", label: "PPA tariff", suffix: "$ / MWh", step: 0.01 },
  { key: "omCostPerKwYear", label: "O&M cost", suffix: "$ / kW / yr", step: 0.1 },
  { key: "landLeasePerYear", label: "Land lease", suffix: "$ / yr", step: 1000 },
  { key: "debtTenor", label: "Senior debt tenor", suffix: "years", step: 1 },
  { key: "interestRatePct", label: "Interest rate", suffix: "%", step: 0.01 },
  { key: "targetDscr", label: "Target DSCR", suffix: "x", step: 0.01 },
  { key: "costOfEquityPct", label: "Cost of equity", suffix: "%", step: 0.01 },
];

const advancedFields: FieldDefinition[] = [
  { key: "ppaEscalationPct", label: "PPA escalation", suffix: "%", step: 0.1 },
  { key: "ppaTerm", label: "PPA term", suffix: "years", step: 1 },
  { key: "omEscalationPct", label: "O&M escalation", suffix: "%", step: 0.1 },
  { key: "landEscalationPct", label: "Land lease escalation", suffix: "%", step: 0.1 },
  { key: "workingCapitalPct", label: "Working capital reserve", suffix: "% next-year opex", step: 0.1 },
  { key: "depreciableLife", label: "Depreciable life", suffix: "years", step: 1 },
  { key: "taxRatePct", label: "Corporate tax rate", suffix: "%", step: 0.1 },
  { key: "idcDrawPct", label: "Average construction debt drawn", suffix: "%", step: 0.1 },
  { key: "idcInterestRatePct", label: "IDC interest rate", suffix: "%", step: 0.01 },
  { key: "energyUncertaintyPct", label: "Energy uncertainty (1σ)", suffix: "%", step: 0.1 },
  { key: "zScore", label: "P90 exceedance z score", suffix: "z", step: 0.0001 },
  { key: "gridEmissionFactor", label: "Grid emission factor", suffix: "tCO2e / MWh", step: 0.01 },
  { key: "carbonPrice", label: "Carbon credit price", suffix: "$ / tCO2e", step: 0.01 },
  { key: "carbonPriceEscalationPct", label: "Carbon price escalation", suffix: "%", step: 0.1 },
];

function money(value: number, decimals = 1) {
  if (!Number.isFinite(value)) return "—";
  const absolute = Math.abs(value);
  const sign = value < 0 ? "−" : "";
  if (absolute >= 1_000_000_000) return `${sign}$${(absolute / 1_000_000_000).toFixed(decimals)}bn`;
  if (absolute >= 1_000_000) return `${sign}$${(absolute / 1_000_000).toFixed(decimals)}m`;
  if (absolute >= 1_000) return `${sign}$${(absolute / 1_000).toFixed(decimals)}k`;
  return `${sign}$${absolute.toFixed(0)}`;
}

function percent(value: number | null) {
  return value === null || !Number.isFinite(value) ? "Not meaningful" : `${(value * 100).toFixed(2)}%`;
}

function whole(value: number) {
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);
}

function NumericField({
  definition,
  value,
  error,
  onChange,
}: {
  definition: FieldDefinition;
  value: number;
  error?: string;
  onChange: (value: number) => void;
}) {
  const id = definition.key;
  return (
    <div className="field">
      <label className="field-label" htmlFor={id}>
        {definition.label}<span>{definition.suffix}</span>
      </label>
      <div className="input-wrap">
        <input
          id={id}
          data-testid={`input-${id}`}
          type="number"
          inputMode="decimal"
          value={Number.isFinite(value) ? value : ""}
          step={definition.step ?? "any"}
          onChange={(event) => onChange(event.target.value === "" ? Number.NaN : Number(event.target.value))}
          aria-invalid={Boolean(error)}
          aria-describedby={`${id}-help ${id}-error`}
        />
        <span className="input-suffix">{definition.suffix}</span>
      </div>
      {definition.help ? <p className="field-help" id={`${id}-help`}>{definition.help}</p> : null}
      {error ? <p className="field-error" id={`${id}-error`} role="alert">{error}</p> : null}
    </div>
  );
}

function Toggle({
  id,
  label,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="toggle-row" htmlFor={id}>
      <span>{label}</span>
      <input id={id} type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <span className="toggle-track" aria-hidden="true"><span /></span>
    </label>
  );
}

function CashflowChart({ data, tenor }: { data: YearData[]; tenor: number }) {
  const chartData = data.filter((item) => item.year > 0 && item.year <= tenor);
  const maxValue = Math.max(...chartData.map((item) => Math.max(item.cfadsLender, item.debtService)), 1);
  const chartHeight = 130;
  const xStep = 320 / Math.max(chartData.length - 1, 1);
  const points = (key: "cfadsLender" | "debtService") =>
    chartData.map((item, index) => `${24 + index * xStep},${chartHeight - (item[key] / maxValue) * 91 + 8}`).join(" ");
  return (
    <div className="chart-card" data-testid="chart-cfads-debt-service">
      <div className="chart-head">
        <h3 className="chart-title">CFADS / debt service profile</h3>
        <div className="legend" aria-label="Chart legend">
          <span className="legend-item"><i className="legend-swatch blue" />Lender CFADS</span>
          <span className="legend-item"><i className="legend-swatch dark" />Debt service</span>
        </div>
      </div>
      <div className="chart-wrap">
        <svg viewBox="0 0 368 163" role="img" aria-label="Annual lender CFADS and sculpted senior debt service">
          {[0, 1, 2, 3].map((line) => <line key={line} className="chart-gridline" x1="24" x2="344" y1={17 + line * 30} y2={17 + line * 30} />)}
          <polyline points={points("cfadsLender")} fill="none" stroke="#1E52F3" strokeWidth="2.5" />
          <polyline points={points("debtService")} fill="none" stroke="#252525" strokeWidth="2" strokeDasharray="4 3" />
          {chartData.filter((_, index) => index === 0 || (index + 1) % 5 === 0).map((item, index) => (
            <text key={item.year} x={24 + (item.year - 1) * xStep} y="153" textAnchor="middle" className="axis-label">
              Y{item.year}
            </text>
          ))}
          <text x="24" y="11" className="axis-label">{money(maxValue, 0)}</text>
          <text x="24" y="139" className="axis-label">$0</text>
        </svg>
      </div>
      <div className="chart-foot">Debt service is sculpted to the target DSCR, not level principal.</div>
    </div>
  );
}

function ModelPage() {
  const [inputs, setInputs] = useState<ModelInputs>(DEFAULT_INPUTS);
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState("");
  const validation = useMemo(() => validateInputs(inputs), [inputs]);
  const model = useMemo(() => runModel(inputs), [inputs]);
  const update = <K extends keyof ModelInputs>(key: K, value: ModelInputs[K]) =>
    setInputs((current) => ({ ...current, [key]: value }));
  const exportWorkbook = async () => {
    if (!validation.isValid || isExporting) return;
    setIsExporting(true);
    setExportStatus("Preparing the formula-linked workbook…");
    try {
      await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
      const filename = await downloadWorkbook(inputs);
      setExportStatus(`${filename} is ready.`);
    } catch (error) {
      console.error(error);
      setExportStatus("The workbook could not be generated. Please review the inputs and try again.");
    } finally {
      setIsExporting(false);
    }
  };
  const reset = () => {
    setInputs(DEFAULT_INPUTS);
    setExportStatus("");
  };
  const firstOperatingYear = model.years[1];
  const dscrTone = (model.minDscr ?? 0) >= inputs.targetDscr - 0.0001 ? "good" : "warn";

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="wordmark">
            <span className="wordmark-mark" aria-hidden="true" />
            <div className="wordmark-label">Helio Desk<small>renewable finance tools</small></div>
          </div>
          <div className="topbar-meta">
            <span>Browser-only model generator</span>
            <span className="topbar-status"><ShieldCheck size={12} /> Nothing is uploaded</span>
          </div>
        </div>
      </header>
      <main className="workspace">
        <div className="intro">
          <div>
            <p className="eyebrow">Solar project finance / formula-linked</p>
            <h1>Build the model.<br />See the coverage.</h1>
            <p className="intro-copy">
              Enter a short set of assumptions and download a real project finance model—not a static report.
              Change any blue input in Excel and the workbook re-solves, including the sculpted debt facility.
            </p>
          </div>
          <div className="model-id">
            <strong>MODEL / SOLAR-DSCR</strong><br />
            Five sheets · approximately 3,000 linked formulas
          </div>
        </div>

        <div className="grid">
          <section className="panel" aria-labelledby="assumptions-title">
            <div className="panel-head">
              <div>
                <h2 className="panel-title" id="assumptions-title">Project assumptions</h2>
                <p className="panel-subtitle">Every field has a working default. Results update as you type.</p>
              </div>
              <Calculator size={19} color="#1E52F3" aria-hidden="true" />
            </div>
            <div className="form-body">
              {!validation.isValid ? (
                <div className="error-state" role="alert">
                  <strong>Check the highlighted assumptions.</strong>{" "}
                  {validation.errors.crossField ?? "The workbook will generate when every value is in range."}
                </div>
              ) : null}
              <div className="form-section">
                <p className="section-kicker">Project basics</p>
                <div className="form-grid">
                  <div className="field full">
                    <label className="field-label" htmlFor="projectName">Project name<span>filename & cover</span></label>
                    <div className="input-wrap">
                      <input
                        id="projectName"
                        type="text"
                        value={inputs.projectName}
                        onChange={(event) => update("projectName", event.target.value)}
                        aria-invalid={Boolean(validation.errors.projectName)}
                      />
                    </div>
                    {validation.errors.projectName ? <p className="field-error" role="alert">{validation.errors.projectName}</p> : null}
                  </div>
                  {basicFields.map((definition) => (
                    <NumericField
                      key={definition.key}
                      definition={definition}
                      value={inputs[definition.key]}
                      error={validation.errors[definition.key]}
                      onChange={(value) => update(definition.key, value)}
                    />
                  ))}
                </div>
              </div>

              <details className="advanced">
                <summary>
                  <span>Advanced assumptions <small>Escalation, working capital, tax, P90 and carbon</small></span>
                  <ChevronDown size={16} aria-hidden="true" />
                </summary>
                <div className="advanced-content">
                  <div className="form-grid">
                    <div className="field">
                      <label className="field-label" htmlFor="generationBasis">Generation basis<span>exceedance</span></label>
                      <div className="input-wrap">
                        <select
                          id="generationBasis"
                          value={inputs.generationBasis}
                          onChange={(event) => update("generationBasis", event.target.value as ModelInputs["generationBasis"])}
                        >
                          <option value="P50">P50</option>
                          <option value="P90">P90</option>
                        </select>
                      </div>
                    </div>
                    {advancedFields.map((definition) => (
                      <NumericField
                        key={definition.key}
                        definition={definition}
                        value={inputs[definition.key]}
                        error={validation.errors[definition.key]}
                        onChange={(value) => update(definition.key, value)}
                      />
                    ))}
                    <div className="toggle-group full">
                      <Toggle
                        id="carbonRevenue"
                        label="Include carbon credit revenue"
                        checked={inputs.carbonRevenue}
                        onChange={(checked) => update("carbonRevenue", checked)}
                      />
                      <Toggle
                        id="carbonDebtSizing"
                        label="Count carbon revenue in debt sizing"
                        checked={inputs.carbonDebtSizing}
                        onChange={(checked) => update("carbonDebtSizing", checked)}
                      />
                    </div>
                  </div>
                </div>
              </details>

              <div className="form-actions">
                <span className="calculated-note">
                  Formula-only output · Excel recalculates on open · no circular references
                </span>
                <button className="primary-button" type="button" onClick={exportWorkbook} disabled={!validation.isValid || isExporting}>
                  {isExporting ? "Preparing…" : <><Download size={15} aria-hidden="true" />Generate financial model</>}
                </button>
              </div>
              <div className="inside-file">
                <strong>Inside the file</strong>
                <span>Cover</span><span>Control Room</span><span>Schedules</span><span>Three statements</span>
                <span>FCFF / FCFE</span><span>Integrity checks</span>
              </div>
            </div>
          </section>

          <aside className="panel results" aria-labelledby="results-title">
            <div className="panel-head results-head">
              <div>
                <p className="eyebrow">Live model output</p>
                <h2 className="panel-title" id="results-title">Credit & returns snapshot</h2>
                <p className="panel-subtitle">Independent browser calculation using the current assumptions.</p>
              </div>
              <FileSpreadsheet size={19} color="#9db4ff" aria-hidden="true" />
            </div>
            <div className="results-body">
              <div className="metric-hero">
                <div>
                  <div className="metric-hero-label">Senior debt sized</div>
                  <div className="metric-hero-value">{money(model.seniorDebt, 2)}</div>
                </div>
                <div className="metric-hero-note">Gearing<br /><strong>{(model.gearing * 100).toFixed(1)}%</strong></div>
              </div>
              <div className="metric-grid">
                <div className="metric"><div className="metric-label">Minimum DSCR</div><div className={`metric-value ${dscrTone}`}>{model.minDscr?.toFixed(3) ?? "—"}x</div></div>
                <div className="metric"><div className="metric-label">Project IRR</div><div className="metric-value">{percent(model.projectIrrExcludingIdc)}</div></div>
                <div className="metric"><div className="metric-label">Equity IRR</div><div className="metric-value">{percent(model.equityIrr)}</div></div>
                <div className="metric"><div className="metric-label">Equity NPV</div><div className="metric-value">{money(model.equityNpv ?? 0, 2)}</div></div>
                <div className="metric"><div className="metric-label">Total uses</div><div className="metric-value">{money(model.totalUses, 2)}</div></div>
                <div className="metric"><div className="metric-label">Year 1 lender CFADS</div><div className="metric-value">{money(firstOperatingYear?.cfadsLender ?? 0, 2)}</div></div>
              </div>
              <CashflowChart data={model.years} tenor={inputs.debtTenor} />
              <div className="insight">
                <strong>Read-through:</strong> Year 1 generation is {whole(firstOperatingYear?.generation ?? 0)} MWh.
                Debt service is sculpted to {inputs.targetDscr.toFixed(2)}x and the facility is sized as its present value at {inputs.interestRatePct.toFixed(2)}%.
              </div>
              {model.warnings.map((warning) => <div className="error-state" key={warning}>{warning}</div>)}
              <div className="result-footer">
                <span className="export-status" role="status" aria-live="polite">{exportStatus}</span>
                <button className="secondary-button" type="button" onClick={reset}><RotateCcw size={13} aria-hidden="true" />Reset defaults</button>
              </div>
            </div>
          </aside>
        </div>
        <div className="footer-note">
          <span><Check size={12} strokeWidth={2.5} aria-hidden="true" /> Five-sheet .xlsx · formula linked · recalculates on open</span>
          <span>Free to use. No email gate, sign-up or upload.</span>
        </div>
      </main>
    </div>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  return <ErrorBoundary resetKey="/">{children}</ErrorBoundary>;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <RoutedErrorBoundary><ModelPage /></RoutedErrorBoundary>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}