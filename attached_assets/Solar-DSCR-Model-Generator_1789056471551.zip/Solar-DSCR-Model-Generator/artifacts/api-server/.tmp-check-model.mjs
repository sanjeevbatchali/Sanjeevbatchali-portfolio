// ../../../../../tmp/check-model.ts
import { writeFile } from "node:fs/promises";

// ../solar-model-generator/src/lib/model/types.ts
var DEFAULT_INPUTS = {
  projectName: "Utility-scale solar PV",
  capacityMw: 100,
  yieldHours: 1900,
  degradationPct: 0.5,
  operatingLife: 35,
  epcCostPerKw: 1e3,
  softCostPerKw: 100,
  ppaTariff: 65,
  omCostPerKwYear: 10,
  landLeasePerYear: 1e6,
  debtTenor: 25,
  interestRatePct: 6,
  targetDscr: 1.3,
  costOfEquityPct: 9,
  ppaEscalationPct: 0,
  ppaTerm: 35,
  omEscalationPct: 2,
  landEscalationPct: 2,
  workingCapitalPct: 10,
  depreciableLife: 35,
  taxRatePct: 0,
  idcDrawPct: 50,
  idcInterestRatePct: 6,
  generationBasis: "P50",
  energyUncertaintyPct: 6.9,
  carbonRevenue: true,
  gridEmissionFactor: 0.4,
  carbonPrice: 2.5,
  carbonPriceEscalationPct: 2,
  carbonDebtSizing: false,
  zScore: 1.2816
};

// ../solar-model-generator/src/lib/model/engine.ts
var YEARS = 36;
var EPSILON = 1e-9;
var rate = (pct) => pct / 100;
function validateInputs(inputs) {
  const errors = {};
  const requiredPositive = [
    ["capacityMw", "Installed capacity must be greater than 0 MW."],
    ["epcCostPerKw", "EPC cost must be greater than 0."],
    ["ppaTariff", "PPA tariff must be greater than 0."]
  ];
  for (const [key, message] of requiredPositive) {
    if (typeof inputs[key] !== "number" || inputs[key] <= 0) errors[key] = message;
  }
  const ranges = [
    ["yieldHours", 500, 3e3, "Production yield must be between 500 and 3,000 hours."],
    ["degradationPct", 0, 3, "Annual degradation must be between 0% and 3%."],
    ["operatingLife", 5, 40, "Operating life must be between 5 and 40 years."],
    ["debtTenor", 1, 40, "Senior debt tenor must be between 1 and 40 years."],
    ["interestRatePct", 0, 25, "Interest rate must be between 0% and 25%."],
    ["targetDscr", 1, 3, "Target DSCR must be between 1.00x and 3.00x."],
    ["costOfEquityPct", 0, 40, "Cost of equity must be between 0% and 40%."]
  ];
  for (const [key, min, max, message] of ranges) {
    const value = inputs[key];
    if (typeof value !== "number" || value < min || value > max) errors[key] = message;
  }
  const nonNegative = [
    ["softCostPerKw", "Financing and soft cost cannot be negative."],
    ["omCostPerKwYear", "O&M cost cannot be negative."],
    ["landLeasePerYear", "Land lease cannot be negative."],
    ["ppaEscalationPct", "PPA escalation cannot be negative."],
    ["omEscalationPct", "O&M escalation cannot be negative."],
    ["landEscalationPct", "Land lease escalation cannot be negative."],
    ["workingCapitalPct", "Working capital requirement cannot be negative."],
    ["taxRatePct", "Corporate tax rate cannot be negative."],
    ["idcDrawPct", "Average construction debt drawn cannot be negative."],
    ["idcInterestRatePct", "IDC interest rate cannot be negative."],
    ["energyUncertaintyPct", "Energy uncertainty cannot be negative."],
    ["gridEmissionFactor", "Grid emission factor cannot be negative."],
    ["carbonPrice", "Carbon credit price cannot be negative."],
    ["carbonPriceEscalationPct", "Carbon price escalation cannot be negative."],
    ["zScore", "The z score cannot be negative."]
  ];
  for (const [key, message] of nonNegative) {
    if (typeof inputs[key] !== "number" || inputs[key] < 0) errors[key] = message;
  }
  if (inputs.operatingLife < 1 || inputs.debtTenor > inputs.operatingLife) {
    errors.crossField = "Debt tenor cannot exceed operating life.";
  }
  if (inputs.ppaTerm < 1 || inputs.ppaTerm > inputs.operatingLife) {
    errors.crossField = "PPA term cannot exceed operating life.";
  }
  if (!inputs.projectName.trim()) errors.projectName = "Project name is required.";
  return { errors, isValid: Object.keys(errors).length === 0 };
}
function npv(discountRate, cashFlows) {
  return cashFlows.reduce((sum, cashFlow, index) => sum + cashFlow / (1 + discountRate) ** index, 0);
}
function irr(cashFlows) {
  if (cashFlows.length < 2) return null;
  const hasPositive = cashFlows.some((value) => value > EPSILON);
  const hasNegative = cashFlows.some((value) => value < -EPSILON);
  if (!hasPositive || !hasNegative) return null;
  let low = -0.9999;
  let high = 1;
  let lowValue = npv(low, cashFlows);
  let highValue = npv(high, cashFlows);
  let attempts = 0;
  while (lowValue * highValue > 0 && attempts < 20) {
    high *= 2;
    highValue = npv(high, cashFlows);
    attempts += 1;
  }
  if (lowValue * highValue > 0) return null;
  for (let i = 0; i < 120; i += 1) {
    const mid = (low + high) / 2;
    const midValue = npv(mid, cashFlows);
    if (Math.abs(midValue) < 1e-7) return mid;
    if (lowValue * midValue <= 0) {
      high = mid;
      highValue = midValue;
    } else {
      low = mid;
      lowValue = midValue;
    }
  }
  return (low + high) / 2;
}
function runModel(input = DEFAULT_INPUTS) {
  const inputs = { ...DEFAULT_INPUTS, ...input };
  const validation = validateInputs(inputs);
  if (!validation.isValid) {
    return {
      inputs,
      years: [],
      seniorDebt: 0,
      equityFunding: 0,
      totalUses: 0,
      gearing: 0,
      minDscr: null,
      averageDscr: null,
      maxDscr: null,
      debtRepaidYear: null,
      totalInterest: 0,
      projectIrrExcludingIdc: null,
      projectIrrIncludingIdc: null,
      equityIrr: null,
      projectNpvAtEquityCost: null,
      projectNpvAtWacc: null,
      equityNpv: null,
      warnings: Object.values(validation.errors).filter(Boolean)
    };
  }
  const capacityKw = inputs.capacityMw * 1e3;
  const interestRate = rate(inputs.interestRatePct);
  const idcRate = rate(inputs.idcInterestRatePct);
  const taxRate = rate(inputs.taxRatePct);
  const p50 = 1;
  const p90 = 1 - inputs.zScore * rate(inputs.energyUncertaintyPct);
  const exceedanceFactor = inputs.generationBasis === "P90" ? p90 : p50;
  const years = Array.from({ length: YEARS }, (_, year) => year);
  const base = years.map((year) => {
    const operating = year > 0 && year <= inputs.operatingLife ? 1 : 0;
    const degradationFactor = operating ? (1 - rate(inputs.degradationPct)) ** (year - 1) : 0;
    const generation = operating ? inputs.capacityMw * degradationFactor * inputs.yieldHours * exceedanceFactor : 0;
    const tariff = operating && year <= inputs.ppaTerm ? inputs.ppaTariff * (1 + rate(inputs.ppaEscalationPct)) ** (year - 1) : 0;
    const ppaRevenue = generation * tariff;
    const emissionFactor = operating ? inputs.gridEmissionFactor : 0;
    const carbonVolume = generation * emissionFactor;
    const carbonPrice = operating ? inputs.carbonPrice * (1 + rate(inputs.carbonPriceEscalationPct)) ** (year - 1) : 0;
    const carbonRevenue = carbonVolume * carbonPrice * (inputs.carbonRevenue ? 1 : 0);
    const totalRevenue = ppaRevenue + carbonRevenue;
    const omRate = operating ? inputs.omCostPerKwYear * (1 + rate(inputs.omEscalationPct)) ** (year - 1) : 0;
    const om = omRate * (operating ? capacityKw : 0);
    const land = operating ? inputs.landLeasePerYear * (1 + rate(inputs.landEscalationPct)) ** (year - 1) : 0;
    const opex = om + land;
    const ebitda = totalRevenue - opex;
    return {
      year,
      operating,
      generation,
      tariff,
      ppaRevenue,
      carbonRevenue,
      totalRevenue,
      omRate,
      om,
      land,
      opex,
      ebitda
    };
  });
  for (let year = 0; year < YEARS; year += 1) {
    const nextOpex = year < YEARS - 1 ? Number(base[year + 1].opex ?? 0) : 0;
    base[year].workingCapitalBalance = year < YEARS - 1 ? rate(inputs.workingCapitalPct) * nextOpex : 0;
    base[year].workingCapitalMovement = year === 0 ? 0 : -((base[year].workingCapitalBalance ?? 0) - (base[year - 1].workingCapitalBalance ?? 0));
    base[year].epcCost = year === 0 ? inputs.epcCostPerKw * capacityKw : 0;
    base[year].softCost = year === 0 ? inputs.softCostPerKw * capacityKw : 0;
    base[year].capex = (base[year].epcCost ?? 0) + (base[year].softCost ?? 0) + (base[year].idc ?? 0);
    base[year].workingCapitalFunding = year === 0 ? base[year].workingCapitalBalance : 0;
    base[year].uses = (base[year].capex ?? 0) + (base[year].workingCapitalFunding ?? 0);
    base[year].cfadsForSizing = (base[year].generation ?? 0) * (base[year].tariff ?? 0) + (inputs.carbonDebtSizing ? base[year].carbonRevenue ?? 0 : 0) - (base[year].opex ?? 0) + (base[year].workingCapitalMovement ?? 0);
    base[year].cfadsLender = (base[year].ppaRevenue ?? 0) + (inputs.carbonDebtSizing ? base[year].carbonRevenue ?? 0 : 0) - (base[year].opex ?? 0) + (base[year].workingCapitalMovement ?? 0);
    base[year].cfadsTotal = (base[year].totalRevenue ?? 0) - (base[year].opex ?? 0) + (base[year].workingCapitalMovement ?? 0);
    base[year].targetDebtService = year >= 1 && year <= inputs.debtTenor ? Math.max(0, (base[year].cfadsForSizing ?? 0) / inputs.targetDscr) : 0;
  }
  const debtServiceStream = base.slice(1).map((row) => Number(row.targetDebtService ?? 0));
  const seniorDebt = npv(interestRate, [0, ...debtServiceStream]);
  const idc = seniorDebt * idcRate * rate(inputs.idcDrawPct);
  base[0].idc = idc;
  base[0].capex = (base[0].epcCost ?? 0) + (base[0].softCost ?? 0) + idc;
  base[0].uses = (base[0].capex ?? 0) + (base[0].workingCapitalFunding ?? 0);
  for (let year = 1; year < YEARS; year += 1) {
    base[year].idc = 0;
    base[year].capex = (base[year].epcCost ?? 0) + (base[year].softCost ?? 0);
    base[year].uses = (base[year].capex ?? 0) + (base[year].workingCapitalFunding ?? 0);
  }
  let debtClosing = 0;
  let grossBookClosing = 0;
  let accumulatedDepClosingValue = 0;
  let shareCapital = 0;
  let retainedEarnings = 0;
  let closingCash = 0;
  const completeYears = base.map((row, year) => {
    const grossBookValueOpening = year === 0 ? 0 : grossBookClosing;
    const grossBookValueAddition = Number(row.capex ?? 0);
    const grossBookValueClosing = grossBookValueOpening + grossBookValueAddition;
    grossBookClosing = grossBookValueClosing;
    const accumulatedDepOpening = year === 0 ? 0 : accumulatedDepClosingValue;
    const depreciation = row.operating && year <= inputs.depreciableLife ? grossBookValueClosing / inputs.depreciableLife : 0;
    const accumulatedDepClosing = accumulatedDepOpening + depreciation;
    accumulatedDepClosingValue = accumulatedDepClosing;
    const netBookValue = grossBookValueClosing - accumulatedDepClosing;
    const debtOpening = year === 0 ? 0 : year === 1 ? seniorDebt : debtClosing;
    const debtInterest = debtOpening * interestRate;
    const scheduledService = Number(row.targetDebtService ?? 0);
    const debtPrincipal = scheduledService > debtInterest ? Math.min(debtOpening, scheduledService - debtInterest) : 0;
    const debtService = debtInterest + debtPrincipal;
    debtClosing = Math.max(0, debtOpening - debtPrincipal);
    const dscr = scheduledService > EPSILON && debtOpening > EPSILON ? (row.cfadsLender ?? 0) / scheduledService : null;
    const debtDraw = year === 0 ? seniorDebt : 0;
    const equityContribution = (row.uses ?? 0) - debtDraw;
    const pbt = (row.ebitda ?? 0) - depreciation - debtInterest;
    const tax = -pbt * taxRate;
    const profitAfterTax = pbt + tax;
    shareCapital = year === 0 ? equityContribution : shareCapital + equityContribution;
    const cfo = profitAfterTax + depreciation + debtInterest;
    const cfi = -(row.capex ?? 0);
    const cfade = (row.cfadsTotal ?? 0) - debtService;
    retainedEarnings = year === 0 ? profitAfterTax : retainedEarnings + profitAfterTax - cfade;
    const totalEquity = shareCapital + retainedEarnings;
    const cff = debtDraw - debtPrincipal - debtInterest + equityContribution - cfade;
    const netCashMovement = cfo + cfi + cff;
    const openingCash = year === 0 ? 0 : closingCash;
    closingCash = openingCash + netCashMovement;
    const fcff = (row.ebitda ?? 0) + tax + Number(row.workingCapitalMovement ?? 0) - Number(row.workingCapitalFunding ?? 0) - (row.capex ?? 0);
    const projectCashFlowExcludingIdc2 = fcff + Number(row.idc ?? 0);
    const fcfe = fcff - debtInterest + debtDraw - debtPrincipal;
    return {
      year,
      operating: Number(row.operating ?? 0),
      generation: Number(row.generation ?? 0),
      tariff: Number(row.tariff ?? 0),
      ppaRevenue: Number(row.ppaRevenue ?? 0),
      carbonRevenue: Number(row.carbonRevenue ?? 0),
      totalRevenue: Number(row.totalRevenue ?? 0),
      omRate: Number(row.omRate ?? 0),
      om: Number(row.om ?? 0),
      land: Number(row.land ?? 0),
      opex: Number(row.opex ?? 0),
      ebitda: Number(row.ebitda ?? 0),
      workingCapitalBalance: Number(row.workingCapitalBalance ?? 0),
      workingCapitalMovement: Number(row.workingCapitalMovement ?? 0),
      epcCost: Number(row.epcCost ?? 0),
      softCost: Number(row.softCost ?? 0),
      idc: Number(row.idc ?? 0),
      capex: Number(row.capex ?? 0),
      workingCapitalFunding: Number(row.workingCapitalFunding ?? 0),
      uses: Number(row.uses ?? 0),
      debtDraw,
      equityContribution,
      grossBookValueOpening,
      grossBookValueAddition,
      grossBookValueClosing,
      accumulatedDepOpening,
      depreciation,
      accumulatedDepClosing,
      netBookValue,
      cfadsForSizing: Number(row.cfadsForSizing ?? 0),
      cfadsLender: Number(row.cfadsLender ?? 0),
      cfadsTotal: Number(row.cfadsTotal ?? 0),
      targetDebtService: scheduledService,
      debtOpening,
      debtInterest,
      debtPrincipal,
      debtClosing,
      debtService,
      dscr,
      cashAvailableForDistribution: cfade,
      pbt,
      tax,
      profitAfterTax,
      shareCapital,
      retainedEarnings,
      totalEquity,
      closingCash,
      cfo,
      cfi,
      cff,
      netCashMovement,
      fcff,
      projectCashFlowExcludingIdc: projectCashFlowExcludingIdc2,
      fcfe
    };
  });
  const operatingYears = completeYears.filter((row) => row.year >= 1 && row.year <= inputs.operatingLife);
  const dscrs = operatingYears.map((row) => row.dscr).filter((value) => value !== null);
  const projectCashFlowIncludingIdc = completeYears.map((row) => row.fcff);
  const projectCashFlowExcludingIdc = completeYears.map((row) => row.projectCashFlowExcludingIdc);
  const equityCashFlow = completeYears.map((row) => row.fcfe);
  const equityFunding = completeYears[0]?.equityContribution ?? 0;
  const totalUses = completeYears[0]?.uses ?? 0;
  const projectNpvAtEquityCost = npv(rate(inputs.costOfEquityPct), projectCashFlowExcludingIdc);
  const equityNpv = npv(rate(inputs.costOfEquityPct), equityCashFlow);
  const wacc = totalUses > 0 ? seniorDebt / totalUses * interestRate + equityFunding / totalUses * rate(inputs.costOfEquityPct) : rate(inputs.costOfEquityPct);
  const projectNpvAtWacc = npv(wacc, projectCashFlowExcludingIdc);
  const debtRepaidYear = completeYears.find((row) => row.year >= 1 && row.debtClosing <= 0.01)?.year ?? null;
  const warnings = [];
  if (seniorDebt <= EPSILON) warnings.push("These inputs do not support a senior debt facility.");
  if (operatingYears.some((row) => row.cfadsForSizing < 0)) {
    warnings.push("CFADS turns negative in at least one operating year; debt sizing is floored at zero for that year.");
  }
  return {
    inputs,
    years: completeYears,
    seniorDebt,
    equityFunding,
    totalUses,
    gearing: totalUses > 0 ? seniorDebt / totalUses : 0,
    minDscr: dscrs.length ? Math.min(...dscrs) : null,
    averageDscr: dscrs.length ? dscrs.reduce((sum, value) => sum + value, 0) / dscrs.length : null,
    maxDscr: dscrs.length ? Math.max(...dscrs) : null,
    debtRepaidYear,
    totalInterest: completeYears.reduce((sum, row) => sum + row.debtInterest, 0),
    projectIrrExcludingIdc: irr(projectCashFlowExcludingIdc),
    projectIrrIncludingIdc: irr(projectCashFlowIncludingIdc),
    equityIrr: irr(equityCashFlow),
    projectNpvAtEquityCost,
    projectNpvAtWacc,
    equityNpv,
    warnings
  };
}

// ../solar-model-generator/src/lib/model/workbook.ts
var BLUE = "1E52F3";
var DARK = "252525";
var WHITE = "FFFFFF";
var PALE = "EDF1FE";
var GREY = "F5F5F5";
var MID = "8A8A8A";
var RULE = "D6D6D6";
var MONEY = '#,##0;(#,##0);"-"';
var PRICE = '#,##0.00;(#,##0.00);"-"';
var PCT = "0.0%";
var PCT2 = "0.00%";
var MULT = '0.00"x"';
var MWH = "#,##0";
var FIRST_YEAR_COL = 5;
var LAST_YEAR_COL = 40;
function colLetter(column) {
  let result = "";
  let current = column;
  while (current > 0) {
    const remainder = (current - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    current = Math.floor((current - 1) / 26);
  }
  return result;
}
function styleCell(cell, options = {}) {
  cell.font = {
    name: "Arial",
    size: options.size ?? 9,
    bold: options.bold ?? false,
    italic: options.italic ?? false,
    color: { argb: options.color ?? DARK }
  };
  if (options.fill) {
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: options.fill } };
  }
  cell.alignment = {
    horizontal: options.align ?? "left",
    vertical: "middle"
  };
  if (options.numFmt) cell.numFmt = options.numFmt;
  if (options.borderBottom) {
    cell.border = { bottom: { style: "thin", color: { argb: RULE } } };
  }
}
function configureSheet(sheet, timeline = false) {
  sheet.views = timeline ? [{ state: "frozen", xSplit: 4, ySplit: 6, topLeftCell: "E7", showGridLines: false }] : [{ showGridLines: false }];
  sheet.getColumn(1).width = 2.5;
  sheet.getColumn(2).width = 3;
  sheet.getColumn(3).width = timeline ? 48 : 36;
  sheet.getColumn(4).width = 15;
  if (timeline) {
    for (let column = FIRST_YEAR_COL; column <= LAST_YEAR_COL; column += 1) {
      sheet.getColumn(column).width = 14;
    }
  }
  sheet.properties.defaultRowHeight = 15;
}
function setFormula(cell, formula, numFmt) {
  cell.value = { formula: formula.replace(/^=/, "") };
  styleCell(cell, { align: "right", numFmt });
}
function addBand(sheet, row, title, endColumn = 8) {
  sheet.getCell(row, 3).value = title;
  for (let column = 3; column <= endColumn; column += 1) {
    styleCell(sheet.getCell(row, column), {
      fill: DARK,
      color: WHITE,
      bold: true,
      size: 9
    });
  }
  sheet.getRow(row).height = 19;
}
function addTitle(sheet, title, subtitle, endColumn = 40) {
  sheet.getCell("B1").value = title;
  sheet.mergeCells(1, 2, 1, endColumn);
  styleCell(sheet.getCell("B1"), { fill: BLUE, color: WHITE, bold: true, size: 11 });
  for (let column = 3; column <= endColumn; column += 1) {
    styleCell(sheet.getCell(1, column), { fill: BLUE, color: WHITE });
  }
  sheet.getRow(1).height = 24;
  sheet.getCell("B2").value = subtitle;
  sheet.mergeCells(2, 2, 2, endColumn);
  styleCell(sheet.getCell("B2"), { color: MID, italic: true, size: 8 });
}
function createControlRoom(workbook, inputs) {
  const sheet = workbook.addWorksheet("Control Room", { properties: { tabColor: { argb: BLUE } } });
  configureSheet(sheet);
  sheet.getColumn(3).width = 48;
  sheet.getColumn(4).width = 22;
  sheet.getColumn(5).width = 20;
  sheet.getColumn(6).width = 54;
  addTitle(
    sheet,
    "CONTROL ROOM  |  Model assumptions",
    "Every typed assumption sits on this sheet. Blue cells are safe to change; black cells are calculated.",
    6
  );
  const rows = {};
  let row = 4;
  const section = (title) => {
    addBand(sheet, row, title, 6);
    row += 1;
  };
  const input = (key, label, value, unit, note, numFmt) => {
    rows[key] = row;
    sheet.getCell(row, 3).value = label;
    sheet.getCell(row, 4).value = value;
    sheet.getCell(row, 5).value = unit;
    sheet.getCell(row, 6).value = note;
    styleCell(sheet.getCell(row, 3), { borderBottom: true });
    styleCell(sheet.getCell(row, 4), {
      fill: PALE,
      color: BLUE,
      bold: true,
      align: typeof value === "number" ? "right" : "left",
      numFmt,
      borderBottom: true
    });
    styleCell(sheet.getCell(row, 5), { color: MID, borderBottom: true });
    styleCell(sheet.getCell(row, 6), { color: MID, italic: true, size: 8, borderBottom: true });
    row += 1;
  };
  const calculated = (key, label, formula, unit, note, numFmt) => {
    rows[key] = row;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), formula, numFmt);
    sheet.getCell(row, 5).value = unit;
    sheet.getCell(row, 6).value = note;
    styleCell(sheet.getCell(row, 4), { fill: GREY, align: "right", numFmt, borderBottom: true });
    styleCell(sheet.getCell(row, 3), { borderBottom: true });
    styleCell(sheet.getCell(row, 5), { color: MID, borderBottom: true });
    styleCell(sheet.getCell(row, 6), { color: MID, italic: true, size: 8, borderBottom: true });
    row += 1;
  };
  const cr = (key) => `'Control Room'!$D$${rows[key]}`;
  section("1.  PROJECT BASICS");
  input("project_name", "Project name", inputs.projectName, "", "Used on the Cover and in the downloaded filename.");
  input("cap_mw", "Installed capacity", inputs.capacityMw, "MW", "DC/AC nameplate capacity used for generation.", PRICE);
  calculated("cap_kw", "Installed capacity", `=${cr("cap_mw")}*1000`, "kW", "Calculated unit conversion.", MONEY);
  input("yield", "Production yield", inputs.yieldHours, "hours / year", "Annual equivalent full-load hours.", MONEY);
  input("degr", "Annual degradation", inputs.degradationPct / 100, "%", "Applied from Year 2 onward.", PCT);
  input("life", "Operating life", inputs.operatingLife, "years", "Operating flag stops all activity after this year.", "0");
  input("epc", "EPC cost", inputs.epcCostPerKw, "$ / kW", "Turnkey engineering, procurement and construction cost.", PRICE);
  input("soft", "Financing and soft cost", inputs.softCostPerKw, "$ / kW", "Development and financing costs excluding IDC.", PRICE);
  input("ppa", "PPA tariff", inputs.ppaTariff, "$ / MWh", "Year 1 contracted power price.", PRICE);
  input("om", "O&M cost", inputs.omCostPerKwYear, "$ / kW / yr", "Year 1 operating and maintenance cost.", PRICE);
  input("land", "Land lease", inputs.landLeasePerYear, "$ / yr", "Year 1 land lease payment.", MONEY);
  input("tenor", "Senior debt tenor", inputs.debtTenor, "years", "Debt service is sculpted within this period.", "0");
  input("rate", "Senior debt interest rate", inputs.interestRatePct / 100, "%", "Annual nominal rate, paid in arrears.", PCT2);
  input("dscr", "Target DSCR", inputs.targetDscr, "x", "Annual debt service equals lender CFADS divided by this target.", MULT);
  input("coe", "Cost of equity", inputs.costOfEquityPct / 100, "%", "Discount rate used for equity NPV.", PCT2);
  section("2.  ADVANCED ASSUMPTIONS");
  input("ppa_esc", "PPA escalation", inputs.ppaEscalationPct / 100, "%", "First applied in Year 2.", PCT);
  input("ppa_term", "PPA term", inputs.ppaTerm, "years", "Power revenue ends after this year.", "0");
  input("om_esc", "O&M escalation", inputs.omEscalationPct / 100, "%", "First applied in Year 2.", PCT);
  input("land_esc", "Land lease escalation", inputs.landEscalationPct / 100, "%", "First applied in Year 2.", PCT);
  input("wc_pct", "Working capital requirement", inputs.workingCapitalPct / 100, "% next year opex", "Held as a funded cash reserve and released in the final year.", PCT);
  input("depr_life", "Depreciable life", inputs.depreciableLife, "years", "Straight-line depreciation with no residual value.", "0");
  input("tax", "Corporate tax rate", inputs.taxRatePct / 100, "%", "Model is pre-tax by default.", PCT);
  input("idc_draw", "Average construction debt drawn", inputs.idcDrawPct / 100, "%", "Average debt balance used for IDC.", PCT);
  input("idc_rate", "IDC interest rate", inputs.idcInterestRatePct / 100, "%", "Applied to the average construction debt balance.", PCT2);
  section("3.  GENERATION & CARBON");
  input("basis", "Generation basis", inputs.generationBasis, "P50 / P90", "Switches the exceedance factor used for generation.");
  input("sigma", "Energy uncertainty, one standard deviation", inputs.energyUncertaintyPct / 100, "%", "One standard deviation around expected generation.", PCT);
  input("z", "z score at the 90% exceedance level", inputs.zScore, "z", "Default 1.2816; avoids compatibility-dependent distribution functions.", "0.0000");
  calculated("p50", "P50 exceedance factor", "=1", "x", "Expected generation case.", "0.0000");
  calculated("p90", "P90 exceedance factor", `=${cr("p50")}-${cr("z")}*${cr("sigma")}`, "x", "One-sided 90% exceedance factor.", "0.0000");
  calculated("exc_factor", "Selected exceedance factor", `=IF(${cr("basis")}="P90",${cr("p90")},${cr("p50")})`, "x", "Feeds the generation schedule.", "0.0000");
  input("carbon_sw", "Carbon credit revenue", inputs.carbonRevenue ? 1 : 0, "1 = on", "Switch for carbon revenue.", "0");
  input("ef", "Grid emission factor", inputs.gridEmissionFactor, "tCO2e / MWh", "Avoided grid emissions per MWh.", "0.000");
  input("cprice", "Carbon credit price", inputs.carbonPrice, "$ / tCO2e", "Year 1 carbon price.", PRICE);
  input("cesc", "Carbon credit price escalation", inputs.carbonPriceEscalationPct / 100, "%", "First applied in Year 2.", PCT);
  input("carbon_debt", "Carbon revenue counted in debt sizing", inputs.carbonDebtSizing ? 1 : 0, "1 = yes", "Default excludes uncontracted attribute revenue from lender CFADS.", "0");
  section("4.  MODEL CONVENTIONS");
  sheet.getCell(row, 3).value = "Timeline";
  sheet.getCell(row, 4).value = "Year 0 to Year 35";
  sheet.getCell(row, 6).value = "Year 0 is the construction year; annual operating cash flows occur in arrears.";
  row += 1;
  sheet.getCell(row, 3).value = "Currency and units";
  sheet.getCell(row, 4).value = "USD, actual";
  sheet.getCell(row, 6).value = "No hidden scaling in the calculations.";
  row += 1;
  sheet.getCell(row, 3).value = "Tax / incentives";
  sheet.getCell(row, 4).value = "Pre-tax base case";
  sheet.getCell(row, 6).value = "No tax equity, ITC, MACRS, terminal value or residual value.";
  return { sheet, rows, cr };
}
function createSchedules(workbook, cr) {
  const sheet = workbook.addWorksheet("Schedules", { properties: { tabColor: { argb: "4A67A1" } } });
  configureSheet(sheet, true);
  addTitle(
    sheet,
    "SCHEDULES  |  Operating, funding and debt back-workings",
    "Year 0 is construction. Years 1\u201335 are annual operating periods. Formula references are fully linked to the Control Room."
  );
  const orderedKeys = [
    "per",
    "yr",
    "phase",
    "op",
    "nameplate",
    "degf",
    "active",
    "yield",
    "exc",
    "gen",
    "tariff",
    "ppa_rev",
    "ef",
    "tco2",
    "cprice",
    "c_rev",
    "tot_rev",
    "om_rate",
    "om",
    "land",
    "opex",
    "ebitda",
    "wc_bal",
    "wc_mov",
    "epc_c",
    "soft_c",
    "idc",
    "capex",
    "wc_fund",
    "uses",
    "draw",
    "equity",
    "sources",
    "gb_o",
    "gb_a",
    "gb_c",
    "ad_o",
    "dep",
    "ad_c",
    "nb",
    "cfads_f",
    "cfads_l",
    "cfads_t",
    "tgt",
    "ds",
    "d_o",
    "d_i",
    "d_p",
    "d_c",
    "dsp",
    "dscr",
    "cfade"
  ];
  const rows = {};
  let row = 6;
  for (const key of orderedKeys) {
    rows[key] = row;
    row += 1;
    if (["op", "gen", "tot_rev", "ebitda", "wc_mov", "sources", "nb", "cfade"].includes(key)) row += 1;
  }
  const ref = (column, key) => `${column}${rows[key]}`;
  const labels = {
    per: ["Period counter", "#", "0"],
    yr: ["Year", "", void 0],
    phase: ["Phase", "", void 0],
    op: ["Operating flag", "1 / 0", "0"],
    nameplate: ["Nameplate capacity", "MW", PRICE],
    degf: ["Degradation factor", "x", "0.0000"],
    active: ["Active capacity", "MW", PRICE],
    yield: ["Production yield", "hours", MONEY],
    exc: ["Exceedance factor", "x", "0.0000"],
    gen: ["Net generation", "MWh", MWH],
    tariff: ["PPA tariff", "$ / MWh", PRICE],
    ppa_rev: ["Revenue from power sales", "$", MONEY],
    ef: ["Grid emission factor", "tCO2e / MWh", "0.000"],
    tco2: ["Avoided emissions", "tCO2e", MWH],
    cprice: ["Carbon credit price", "$ / tCO2e", PRICE],
    c_rev: ["Revenue from carbon credits", "$", MONEY],
    tot_rev: ["Total revenue", "$", MONEY],
    om_rate: ["O&M rate", "$ / kW / yr", PRICE],
    om: ["Operations & maintenance", "$", MONEY],
    land: ["Land lease", "$", MONEY],
    opex: ["Total operating expenditure", "$", MONEY],
    ebitda: ["EBITDA", "$", MONEY],
    wc_bal: ["Working capital reserve balance", "$", MONEY],
    wc_mov: ["Movement in working capital", "$", MONEY],
    epc_c: ["EPC cost", "$", MONEY],
    soft_c: ["Financing and soft cost", "$", MONEY],
    idc: ["Interest during construction", "$", MONEY],
    capex: ["Total construction capital expenditure", "$", MONEY],
    wc_fund: ["Initial working capital funding", "$", MONEY],
    uses: ["Total uses", "$", MONEY],
    draw: ["Senior debt drawdown", "$", MONEY],
    equity: ["Equity contribution", "$", MONEY],
    sources: ["Total sources", "$", MONEY],
    gb_o: ["Gross book value \u2014 opening", "$", MONEY],
    gb_a: ["Gross book value \u2014 additions", "$", MONEY],
    gb_c: ["Gross book value \u2014 closing", "$", MONEY],
    ad_o: ["Accumulated depreciation \u2014 opening", "$", MONEY],
    dep: ["Depreciation", "$", MONEY],
    ad_c: ["Accumulated depreciation \u2014 closing", "$", MONEY],
    nb: ["PP&E net book value", "$", MONEY],
    cfads_f: ["CFADS \u2014 debt sizing case", "$", MONEY],
    cfads_l: ["CFADS \u2014 lender case", "$", MONEY],
    cfads_t: ["CFADS \u2014 total project", "$", MONEY],
    tgt: ["Target DSCR", "x", MULT],
    ds: ["Scheduled debt service", "$", MONEY],
    d_o: ["Senior debt \u2014 opening", "$", MONEY],
    d_i: ["Senior debt \u2014 interest", "$", MONEY],
    d_p: ["Senior debt \u2014 principal", "$", MONEY],
    d_c: ["Senior debt \u2014 closing", "$", MONEY],
    dsp: ["Debt service paid", "$", MONEY],
    dscr: ["Debt service coverage ratio", "x", MULT],
    cfade: ["Cash available for distribution", "$", MONEY]
  };
  const sectionBefore = {
    per: "1.  TIMELINE",
    nameplate: "2.  GENERATION",
    tariff: "3.  REVENUE",
    om_rate: "4.  OPERATING COSTS",
    wc_bal: "5.  WORKING CAPITAL",
    epc_c: "6.  SOURCES & USES",
    gb_o: "7.  PP&E & DEPRECIATION",
    cfads_f: "8.  CFADS, DEBT SIZING & SCULPT",
    cfade: "9.  CASH AVAILABLE FOR DISTRIBUTION"
  };
  for (const key of orderedKeys) {
    const targetRow = rows[key];
    if (sectionBefore[key]) addBand(sheet, targetRow - 1, sectionBefore[key], LAST_YEAR_COL);
    const [label, unit, format] = labels[key];
    sheet.getCell(targetRow, 3).value = label;
    sheet.getCell(targetRow, 4).value = unit;
    styleCell(sheet.getCell(targetRow, 3), { bold: ["gen", "tot_rev", "ebitda", "uses", "sources", "nb", "cfads_t", "dsp", "cfade"].includes(key) });
    styleCell(sheet.getCell(targetRow, 4), { color: MID });
    for (let column = FIRST_YEAR_COL; column <= LAST_YEAR_COL; column += 1) {
      const c = colLetter(column);
      const p = colLetter(Math.max(FIRST_YEAR_COL, column - 1));
      const n = colLetter(Math.min(LAST_YEAR_COL, column + 1));
      const year = column - FIRST_YEAR_COL;
      let formula = "";
      switch (key) {
        case "per":
          sheet.getCell(targetRow, column).value = year;
          styleCell(sheet.getCell(targetRow, column), { align: "right", numFmt: format });
          continue;
        case "yr":
          formula = `="Y"&${ref(c, "per")}`;
          break;
        case "phase":
          formula = `=IF(${ref(c, "per")}=0,"Construction","Operations")`;
          break;
        case "op":
          formula = `=IF(${ref(c, "per")}=0,0,IF(${ref(c, "per")}<=${cr("life")},1,0))`;
          break;
        case "nameplate":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("cap_mw")})`;
          break;
        case "degf":
          formula = `=IF(${ref(c, "op")}=0,0,(1-${cr("degr")})^(${ref(c, "per")}-1))`;
          break;
        case "active":
          formula = `=${ref(c, "nameplate")}*${ref(c, "degf")}`;
          break;
        case "yield":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("yield")})`;
          break;
        case "exc":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("exc_factor")})`;
          break;
        case "gen":
          formula = `=${ref(c, "active")}*${ref(c, "yield")}*${ref(c, "exc")}`;
          break;
        case "tariff":
          formula = `=IF(${ref(c, "op")}=0,0,IF(${ref(c, "per")}>${cr("ppa_term")},0,${cr("ppa")}*(1+${cr("ppa_esc")})^(${ref(c, "per")}-1)))`;
          break;
        case "ppa_rev":
          formula = `=${ref(c, "gen")}*${ref(c, "tariff")}`;
          break;
        case "ef":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("ef")})`;
          break;
        case "tco2":
          formula = `=${ref(c, "gen")}*${ref(c, "ef")}`;
          break;
        case "cprice":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("cprice")}*(1+${cr("cesc")})^(${ref(c, "per")}-1))`;
          break;
        case "c_rev":
          formula = `=${ref(c, "tco2")}*${ref(c, "cprice")}*${cr("carbon_sw")}`;
          break;
        case "tot_rev":
          formula = `=${ref(c, "ppa_rev")}+${ref(c, "c_rev")}`;
          break;
        case "om_rate":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("om")}*(1+${cr("om_esc")})^(${ref(c, "per")}-1))`;
          break;
        case "om":
          formula = `=${ref(c, "om_rate")}*IF(${ref(c, "op")}=0,0,${cr("cap_kw")})`;
          break;
        case "land":
          formula = `=IF(${ref(c, "op")}=0,0,${cr("land")}*(1+${cr("land_esc")})^(${ref(c, "per")}-1))`;
          break;
        case "opex":
          formula = `=${ref(c, "om")}+${ref(c, "land")}`;
          break;
        case "ebitda":
          formula = `=${ref(c, "tot_rev")}-${ref(c, "opex")}`;
          break;
        case "wc_bal":
          formula = column === LAST_YEAR_COL ? "=0" : `=${cr("wc_pct")}*${ref(n, "opex")}`;
          break;
        case "wc_mov":
          formula = year === 0 ? "=0" : `=-(${ref(c, "wc_bal")}-${ref(p, "wc_bal")})`;
          break;
        case "epc_c":
          formula = year === 0 ? `=${cr("epc")}*${cr("cap_kw")}` : "=0";
          break;
        case "soft_c":
          formula = year === 0 ? `=${cr("soft")}*${cr("cap_kw")}` : "=0";
          break;
        case "idc":
          formula = year === 0 ? `=${ref("E", "draw")}*${cr("idc_rate")}*${cr("idc_draw")}` : "=0";
          break;
        case "capex":
          formula = `=SUM(${ref(c, "epc_c")}:${ref(c, "idc")})`;
          break;
        case "wc_fund":
          formula = year === 0 ? `=${ref(c, "wc_bal")}` : "=0";
          break;
        case "uses":
          formula = `=${ref(c, "capex")}+${ref(c, "wc_fund")}`;
          break;
        case "draw":
          formula = year === 0 ? `=NPV(${cr("rate")},${ref("F", "ds")}:${ref("AN", "ds")})` : "=0";
          break;
        case "equity":
          formula = year === 0 ? `=${ref(c, "uses")}-${ref(c, "draw")}` : "=0";
          break;
        case "sources":
          formula = `=${ref(c, "draw")}+${ref(c, "equity")}`;
          break;
        case "gb_o":
          formula = year === 0 ? "=0" : `=${ref(p, "gb_c")}`;
          break;
        case "gb_a":
          formula = `=${ref(c, "capex")}`;
          break;
        case "gb_c":
          formula = `=${ref(c, "gb_o")}+${ref(c, "gb_a")}`;
          break;
        case "ad_o":
          formula = year === 0 ? "=0" : `=${ref(p, "ad_c")}`;
          break;
        case "dep":
          formula = `=IF(${ref(c, "op")}=0,0,IF(${ref(c, "per")}>${cr("depr_life")},0,$E$${rows.gb_c}/${cr("depr_life")}))`;
          break;
        case "ad_c":
          formula = `=${ref(c, "ad_o")}+${ref(c, "dep")}`;
          break;
        case "nb":
          formula = `=${ref(c, "gb_c")}-${ref(c, "ad_c")}`;
          break;
        case "cfads_f":
          formula = `=${ref(c, "gen")}*${ref(c, "tariff")}+${cr("carbon_debt")}*${ref(c, "c_rev")}-${ref(c, "opex")}+${ref(c, "wc_mov")}`;
          break;
        case "cfads_l":
          formula = `=${ref(c, "ppa_rev")}+${cr("carbon_debt")}*${ref(c, "c_rev")}-${ref(c, "opex")}+${ref(c, "wc_mov")}`;
          break;
        case "cfads_t":
          formula = `=${ref(c, "tot_rev")}-${ref(c, "opex")}+${ref(c, "wc_mov")}`;
          break;
        case "tgt":
          formula = `=IF(AND(${ref(c, "per")}>=1,${ref(c, "per")}<=${cr("tenor")}),${cr("dscr")},0)`;
          break;
        case "ds":
          formula = `=IF(${ref(c, "tgt")}=0,0,MAX(0,${ref(c, "cfads_f")}/${ref(c, "tgt")}))`;
          break;
        case "d_o":
          formula = year === 0 ? "=0" : year === 1 ? `=$E$${rows.draw}` : `=${ref(p, "d_c")}`;
          break;
        case "d_i":
          formula = `=${ref(c, "d_o")}*${cr("rate")}`;
          break;
        case "d_p":
          formula = `=IF(${ref(c, "ds")}=0,0,MAX(0,MIN(${ref(c, "d_o")},${ref(c, "ds")}-${ref(c, "d_i")})))`;
          break;
        case "d_c":
          formula = `=MAX(0,${ref(c, "d_o")}-${ref(c, "d_p")})`;
          break;
        case "dsp":
          formula = `=${ref(c, "d_i")}+${ref(c, "d_p")}`;
          break;
        case "dscr":
          formula = `=IF(${ref(c, "ds")}=0,"",IF(${ref(c, "d_o")}=0,"",${ref(c, "cfads_l")}/${ref(c, "ds")}))`;
          break;
        case "cfade":
          formula = `=${ref(c, "cfads_t")}-${ref(c, "dsp")}`;
          break;
      }
      setFormula(sheet.getCell(targetRow, column), formula.replace(/^=/, ""), format);
    }
  }
  return { sheet, rows };
}
function createFinancialStatements(workbook, scheduleRows, cr) {
  const sheet = workbook.addWorksheet("FS", { properties: { tabColor: { argb: "7F8C8D" } } });
  configureSheet(sheet, true);
  addTitle(
    sheet,
    "FINANCIAL STATEMENTS  |  P&L  \xB7  Balance Sheet  \xB7  Cash Flow  \xB7  FCFF  \xB7  FCFE",
    "Pre-tax base case, USD actual. Every calculated value is formula-linked into the Schedules tab."
  );
  const rows = {
    year: 4,
    ppa_rev: 7,
    c_rev: 8,
    total_rev: 9,
    om: 11,
    land: 12,
    total_opex: 13,
    ebitda: 14,
    dep: 16,
    ebit: 17,
    interest: 18,
    pbt: 19,
    tax: 20,
    pat: 21,
    nb: 26,
    cash: 27,
    assets: 28,
    debt: 31,
    liabilities: 32,
    share: 35,
    re: 36,
    equity: 37,
    eq_liab: 38,
    bs_check: 39,
    cfs_pat: 44,
    cfs_dep: 45,
    cfs_interest: 46,
    cfo: 47,
    wc_memo: 48,
    cfads_memo: 49,
    cfs_capex: 52,
    cfi: 53,
    cfs_draw: 56,
    cfs_principal: 57,
    cfs_interest_paid: 58,
    cfs_equity: 59,
    distribution: 60,
    cff: 61,
    net_cash: 63,
    opening_cash: 64,
    closing_cash: 65,
    cash_check: 66,
    fcff: 72,
    project_cf: 73,
    fcfe: 78,
    fcfe_check: 79
  };
  addBand(sheet, 6, "1.  PROFIT & LOSS ACCOUNT", LAST_YEAR_COL);
  addBand(sheet, 25, "2.  BALANCE SHEET", LAST_YEAR_COL);
  addBand(sheet, 43, "3.  CASH FLOW STATEMENT", LAST_YEAR_COL);
  addBand(sheet, 71, "4.  FCFF BRIDGE", LAST_YEAR_COL);
  addBand(sheet, 77, "5.  FCFE BRIDGE", LAST_YEAR_COL);
  const labels = {
    year: ["Year", "", void 0],
    ppa_rev: ["Revenue from power sales", "$", MONEY],
    c_rev: ["Revenue from carbon credits", "$", MONEY],
    total_rev: ["Total revenue", "$", MONEY],
    om: ["Operations & maintenance", "$", MONEY],
    land: ["Land lease", "$", MONEY],
    total_opex: ["Total operating expenditure", "$", MONEY],
    ebitda: ["EBITDA", "$", MONEY],
    dep: ["Depreciation", "$", MONEY],
    ebit: ["EBIT", "$", MONEY],
    interest: ["Interest on senior debt", "$", MONEY],
    pbt: ["Profit before tax", "$", MONEY],
    tax: ["Tax", "$", MONEY],
    pat: ["Profit after tax", "$", MONEY],
    nb: ["PP&E net block", "$", MONEY],
    cash: ["Cash & cash equivalents", "$", MONEY],
    assets: ["TOTAL ASSETS", "$", MONEY],
    debt: ["Senior debt", "$", MONEY],
    liabilities: ["Total liabilities", "$", MONEY],
    share: ["Share capital", "$", MONEY],
    re: ["Retained earnings", "$", MONEY],
    equity: ["Total shareholders' equity", "$", MONEY],
    eq_liab: ["TOTAL EQUITY & LIABILITIES", "$", MONEY],
    bs_check: ["Check: assets less equity & liabilities", "$", MONEY],
    cfs_pat: ["Profit after tax", "$", MONEY],
    cfs_dep: ["Add back: depreciation", "$", MONEY],
    cfs_interest: ["Add back: interest", "$", MONEY],
    cfo: ["Cash flow from operations", "$", MONEY],
    wc_memo: ["Memo: movement in working capital", "$", MONEY],
    cfads_memo: ["Memo: CFADS", "$", MONEY],
    cfs_capex: ["Construction capital expenditure", "$", MONEY],
    cfi: ["Cash flow from investing", "$", MONEY],
    cfs_draw: ["Senior debt drawdown", "$", MONEY],
    cfs_principal: ["Senior debt principal repaid", "$", MONEY],
    cfs_interest_paid: ["Interest paid", "$", MONEY],
    cfs_equity: ["Equity contributed", "$", MONEY],
    distribution: ["Distributions to equity", "$", MONEY],
    cff: ["Cash flow from financing", "$", MONEY],
    net_cash: ["Net movement in cash", "$", MONEY],
    opening_cash: ["Opening cash", "$", MONEY],
    closing_cash: ["Closing cash", "$", MONEY],
    cash_check: ["Check: closing cash less required WC reserve", "$", MONEY],
    fcff: ["FCFF \u2014 including IDC", "$", MONEY],
    project_cf: ["Memo: project cash flow excluding IDC", "$", MONEY],
    fcfe: ["FCFE", "$", MONEY],
    fcfe_check: ["Check: FCFE less distributions net of equity", "$", MONEY]
  };
  const s = (column, key) => `Schedules!${column}${scheduleRows[key]}`;
  const f = (column, key) => `${column}${rows[key]}`;
  for (const [key, [label, unit, format]] of Object.entries(labels)) {
    const row = rows[key];
    sheet.getCell(row, 3).value = label;
    sheet.getCell(row, 4).value = unit;
    styleCell(sheet.getCell(row, 3), {
      bold: ["total_rev", "total_opex", "ebitda", "pat", "assets", "eq_liab", "cfo", "cfi", "cff", "closing_cash", "fcff", "project_cf", "fcfe"].includes(key)
    });
    styleCell(sheet.getCell(row, 4), { color: MID });
    for (let column = FIRST_YEAR_COL; column <= LAST_YEAR_COL; column += 1) {
      const c = colLetter(column);
      const p = colLetter(Math.max(FIRST_YEAR_COL, column - 1));
      const year = column - FIRST_YEAR_COL;
      let formula = "";
      switch (key) {
        case "year":
          formula = `=${s(c, "yr")}`;
          break;
        case "ppa_rev":
          formula = `=${s(c, "ppa_rev")}`;
          break;
        case "c_rev":
          formula = `=${s(c, "c_rev")}`;
          break;
        case "total_rev":
          formula = `=SUM(${f(c, "ppa_rev")}:${f(c, "c_rev")})`;
          break;
        case "om":
          formula = `=-${s(c, "om")}`;
          break;
        case "land":
          formula = `=-${s(c, "land")}`;
          break;
        case "total_opex":
          formula = `=SUM(${f(c, "om")}:${f(c, "land")})`;
          break;
        case "ebitda":
          formula = `=${f(c, "total_rev")}+${f(c, "total_opex")}`;
          break;
        case "dep":
          formula = `=-${s(c, "dep")}`;
          break;
        case "ebit":
          formula = `=${f(c, "ebitda")}+${f(c, "dep")}`;
          break;
        case "interest":
          formula = `=-${s(c, "d_i")}`;
          break;
        case "pbt":
          formula = `=${f(c, "ebit")}+${f(c, "interest")}`;
          break;
        case "tax":
          formula = `=-${f(c, "pbt")}*${cr("tax")}`;
          break;
        case "pat":
          formula = `=${f(c, "pbt")}+${f(c, "tax")}`;
          break;
        case "nb":
          formula = `=${s(c, "nb")}`;
          break;
        case "cash":
          formula = `=${s(c, "wc_bal")}`;
          break;
        case "assets":
          formula = `=SUM(${f(c, "nb")}:${f(c, "cash")})`;
          break;
        case "debt":
          formula = `=${s(c, "draw")}+${s(c, "d_c")}`;
          break;
        case "liabilities":
          formula = `=${f(c, "debt")}`;
          break;
        case "share":
          formula = year === 0 ? `=${s(c, "equity")}` : `=${f(p, "share")}+${s(c, "equity")}`;
          break;
        case "re":
          formula = year === 0 ? `=${f(c, "pat")}` : `=${f(p, "re")}+${f(c, "pat")}-${s(c, "cfade")}`;
          break;
        case "equity":
          formula = `=${f(c, "share")}+${f(c, "re")}`;
          break;
        case "eq_liab":
          formula = `=${f(c, "liabilities")}+${f(c, "equity")}`;
          break;
        case "bs_check":
          formula = `=ROUND(${f(c, "assets")}-${f(c, "eq_liab")},2)`;
          break;
        case "cfs_pat":
          formula = `=${f(c, "pat")}`;
          break;
        case "cfs_dep":
          formula = `=-${f(c, "dep")}`;
          break;
        case "cfs_interest":
          formula = `=-${f(c, "interest")}`;
          break;
        case "cfo":
          formula = `=SUM(${f(c, "cfs_pat")}:${f(c, "cfs_interest")})`;
          break;
        case "wc_memo":
          formula = `=${s(c, "wc_mov")}`;
          break;
        case "cfads_memo":
          formula = `=${f(c, "cfo")}+${f(c, "wc_memo")}`;
          break;
        case "cfs_capex":
          formula = `=-${s(c, "capex")}`;
          break;
        case "cfi":
          formula = `=${f(c, "cfs_capex")}`;
          break;
        case "cfs_draw":
          formula = `=${s(c, "draw")}`;
          break;
        case "cfs_principal":
          formula = `=-${s(c, "d_p")}`;
          break;
        case "cfs_interest_paid":
          formula = `=-${s(c, "d_i")}`;
          break;
        case "cfs_equity":
          formula = `=${s(c, "equity")}`;
          break;
        case "distribution":
          formula = `=-${s(c, "cfade")}`;
          break;
        case "cff":
          formula = `=SUM(${f(c, "cfs_draw")}:${f(c, "distribution")})`;
          break;
        case "net_cash":
          formula = `=${f(c, "cfo")}+${f(c, "cfi")}+${f(c, "cff")}`;
          break;
        case "opening_cash":
          formula = year === 0 ? "=0" : `=${f(p, "closing_cash")}`;
          break;
        case "closing_cash":
          formula = `=${f(c, "opening_cash")}+${f(c, "net_cash")}`;
          break;
        case "cash_check":
          formula = `=ROUND(${f(c, "closing_cash")}-${s(c, "wc_bal")},2)`;
          break;
        case "fcff":
          formula = `=${f(c, "ebitda")}+${f(c, "tax")}+${s(c, "wc_mov")}-${s(c, "wc_fund")}-${s(c, "capex")}`;
          break;
        case "project_cf":
          formula = `=${f(c, "fcff")}+${s(c, "idc")}`;
          break;
        case "fcfe":
          formula = `=${f(c, "fcff")}-${s(c, "d_i")}+${s(c, "draw")}-${s(c, "d_p")}`;
          break;
        case "fcfe_check":
          formula = `=ROUND(${f(c, "fcfe")}-(${s(c, "cfade")}-${s(c, "equity")}),2)`;
          break;
      }
      setFormula(sheet.getCell(row, column), formula.replace(/^=/, ""), format);
    }
  }
  sheet.getCell("C41").value = "Note: a full cash sweep with straight-line depreciation can drive retained earnings negative; the excess distribution is in substance a return of capital.";
  sheet.mergeCells("C41:N41");
  styleCell(sheet.getCell("C41"), { color: MID, italic: true, size: 8 });
  return { sheet, rows };
}
function createOutput(workbook, scheduleRows, fsRows, cr) {
  const sheet = workbook.addWorksheet("Output", { properties: { tabColor: { argb: "16A085" } } });
  configureSheet(sheet);
  sheet.getColumn(3).width = 48;
  for (let column = 4; column <= 12; column += 1) sheet.getColumn(column).width = 18;
  addTitle(
    sheet,
    "OUTPUT  |  Returns, debt metrics and integrity checks",
    "Formula-linked headline metrics, truncated-horizon returns, sources and uses, debt statistics and milestone years.",
    12
  );
  addBand(sheet, 4, "1.  HEADLINE RESULTS", 12);
  const tiles = [
    ["C5", "Equity IRR", "C6", `IRR(FS!E${fsRows.fcfe}:AN${fsRows.fcfe})`, PCT2],
    ["E5", "Equity NPV", "E6", `NPV(${cr("coe")},FS!F${fsRows.fcfe}:AN${fsRows.fcfe})+FS!E${fsRows.fcfe}`, MONEY],
    ["G5", "Project IRR", "G6", `IRR(FS!E${fsRows.project_cf}:AN${fsRows.project_cf})`, PCT2],
    ["I5", "Senior debt", "I6", `Schedules!E${scheduleRows.draw}`, MONEY],
    ["K5", "Minimum DSCR", "K6", `MIN(Schedules!F${scheduleRows.dscr}:INDEX(Schedules!F${scheduleRows.dscr}:AN${scheduleRows.dscr},1,${cr("tenor")}))`, MULT]
  ];
  for (const [labelCell, label, valueCell, formula, format] of tiles) {
    sheet.getCell(labelCell).value = label;
    styleCell(sheet.getCell(labelCell), { color: MID, bold: true });
    setFormula(sheet.getCell(valueCell), formula, format);
    styleCell(sheet.getCell(valueCell), { color: BLUE, bold: true, size: 14, numFmt: format });
  }
  addBand(sheet, 9, "2.  RETURNS BY CASH FLOW HORIZON", 8);
  sheet.getCell("D10").value = "25 years";
  sheet.getCell("E10").value = "30 years";
  sheet.getCell("F10").value = "35 years";
  ["D10", "E10", "F10"].forEach((address) => styleCell(sheet.getCell(address), { fill: GREY, bold: true, align: "center" }));
  const returnRows = [
    ["Project IRR \u2014 excluding IDC", "project_cf", "IRR", PCT2],
    ["Project IRR \u2014 including IDC", "fcff", "IRR", PCT2],
    ["Project NPV at cost of equity", "project_cf", "NPV_COE", MONEY],
    ["Project NPV at blended WACC (memo)", "project_cf", "NPV_WACC", MONEY],
    ["Equity IRR", "fcfe", "IRR", PCT2],
    ["Equity NPV", "fcfe", "NPV_COE", MONEY]
  ];
  returnRows.forEach(([label, key, kind, format], index) => {
    const row = 11 + index;
    sheet.getCell(row, 3).value = label;
    styleCell(sheet.getCell(row, 3), { borderBottom: true });
    [25, 30, 35].forEach((horizon, horizonIndex) => {
      const column = 4 + horizonIndex;
      const end = colLetter(FIRST_YEAR_COL + Math.min(horizon, 35));
      const fsRow = fsRows[key];
      let formula = "";
      if (kind === "IRR") formula = `IRR(FS!E${fsRow}:${end}${fsRow})`;
      if (kind === "NPV_COE") formula = `NPV(${cr("coe")},FS!F${fsRow}:${end}${fsRow})+FS!E${fsRow}`;
      if (kind === "NPV_WACC") {
        formula = `NPV((Schedules!E${scheduleRows.draw}/Schedules!E${scheduleRows.uses})*${cr("rate")}+(Schedules!E${scheduleRows.equity}/Schedules!E${scheduleRows.uses})*${cr("coe")},FS!F${fsRow}:${end}${fsRow})+FS!E${fsRow}`;
      }
      setFormula(sheet.getCell(row, column), formula, format);
    });
  });
  sheet.getCell("C18").value = "Memo: the stated rate is a cost of equity. Discounting unlevered project cash flows at it understates project value; project and equity NPV are shown separately.";
  sheet.mergeCells("C18:H18");
  styleCell(sheet.getCell("C18"), { color: MID, italic: true, size: 8 });
  addBand(sheet, 21, "3.  SOURCES & USES", 8);
  const suRows = [
    ["EPC cost", `Schedules!E${scheduleRows.epc_c}`],
    ["Financing and soft cost", `Schedules!E${scheduleRows.soft_c}`],
    ["Interest during construction", `Schedules!E${scheduleRows.idc}`],
    ["Initial working capital reserve", `Schedules!E${scheduleRows.wc_fund}`],
    ["Total uses", `Schedules!E${scheduleRows.uses}`],
    ["Senior debt", `Schedules!E${scheduleRows.draw}`],
    ["Equity", `Schedules!E${scheduleRows.equity}`],
    ["Gearing", `Schedules!E${scheduleRows.draw}/Schedules!E${scheduleRows.uses}`]
  ];
  suRows.forEach(([label, formula], index) => {
    const row = 22 + index;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), formula, label === "Gearing" ? PCT : MONEY);
  });
  addBand(sheet, 21, "3.  SOURCES & USES", 8);
  addBand(sheet, 32, "4.  SENIOR DEBT & DSCR", 8);
  const debtRows = [
    ["Facility size", `Schedules!E${scheduleRows.draw}`, MONEY],
    ["Tenor", cr("tenor"), "0"],
    ["Minimum DSCR", `MIN(Schedules!F${scheduleRows.dscr}:INDEX(Schedules!F${scheduleRows.dscr}:AN${scheduleRows.dscr},1,${cr("tenor")}))`, MULT],
    ["Average DSCR", `AVERAGE(Schedules!F${scheduleRows.dscr}:INDEX(Schedules!F${scheduleRows.dscr}:AN${scheduleRows.dscr},1,${cr("tenor")}))`, MULT],
    ["Maximum DSCR", `MAX(Schedules!F${scheduleRows.dscr}:INDEX(Schedules!F${scheduleRows.dscr}:AN${scheduleRows.dscr},1,${cr("tenor")}))`, MULT],
    ["Year fully repaid", `MATCH(0,Schedules!F${scheduleRows.d_c}:AN${scheduleRows.d_c},0)`, "0"],
    ["Total interest paid", `SUM(Schedules!F${scheduleRows.d_i}:AN${scheduleRows.d_i})`, MONEY]
  ];
  debtRows.forEach(([label, formula, format], index) => {
    const row = 33 + index;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), formula, format);
  });
  addBand(sheet, 42, "5.  MILESTONE YEARS", 12);
  const milestones = [1, 5, 10, 15, 20, 25, 30, 35];
  milestones.forEach((year, index) => {
    sheet.getCell(43, 4 + index).value = `Year ${year}`;
    styleCell(sheet.getCell(43, 4 + index), { fill: GREY, bold: true, align: "center" });
  });
  const milestoneRows = [
    ["Generation", "gen", MWH],
    ["Total revenue", "tot_rev", MONEY],
    ["EBITDA", "ebitda", MONEY],
    ["CFADS", "cfads_l", MONEY],
    ["Debt service", "dsp", MONEY],
    ["DSCR", "dscr", MULT],
    ["Closing debt", "d_c", MONEY],
    ["Distribution", "cfade", MONEY]
  ];
  milestoneRows.forEach(([label, key, format], rowIndex) => {
    const row = 44 + rowIndex;
    sheet.getCell(row, 3).value = label;
    milestones.forEach((year, columnIndex) => {
      const sourceColumn = colLetter(FIRST_YEAR_COL + year);
      setFormula(sheet.getCell(row, 4 + columnIndex), `Schedules!${sourceColumn}${scheduleRows[key]}`, format);
    });
  });
  addBand(sheet, 55, "6.  INTEGRITY CHECKS", 10);
  const checks = [
    ["Sources less uses at close", `ABS(Schedules!E${scheduleRows.sources}-Schedules!E${scheduleRows.uses})<=0.01`],
    ["Balance sheet, largest imbalance", `ROUND(SUMPRODUCT(MAX(ABS(FS!E${fsRows.bs_check}:AN${fsRows.bs_check}))),2)=0`],
    ["Closing cash less required working capital", `ROUND(SUMPRODUCT(MAX(ABS(FS!E${fsRows.cash_check}:AN${fsRows.cash_check}))),2)=0`],
    ["FCFE less distributions net of equity", `ROUND(SUMPRODUCT(MAX(ABS(FS!E${fsRows.fcfe_check}:AN${fsRows.fcfe_check}))),2)=0`],
    ["Senior debt outstanding after tenor", `ABS(INDEX(Schedules!F${scheduleRows.d_c}:AN${scheduleRows.d_c},1,${cr("tenor")}))<=0.01`],
    ["Minimum DSCR less target", `ABS(MIN(Schedules!F${scheduleRows.dscr}:INDEX(Schedules!F${scheduleRows.dscr}:AN${scheduleRows.dscr},1,${cr("tenor")}))-${cr("dscr")})<=0.0001`],
    ["Retained earnings tie", `ABS(FS!AN${fsRows.equity})<=0.01`]
  ];
  checks.forEach(([label, test], index) => {
    const row = 56 + index;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), `IF(${test},"OK","CHECK")`);
    styleCell(sheet.getCell(row, 4), { bold: true, color: BLUE, align: "center" });
  });
  return sheet;
}
function createCover(workbook, inputs, scheduleRows, fsRows, cr, existingSheet) {
  const sheet = existingSheet ?? workbook.addWorksheet("Cover", { properties: { tabColor: { argb: BLUE } } });
  configureSheet(sheet);
  sheet.getColumn(3).width = 38;
  sheet.getColumn(4).width = 26;
  sheet.getColumn(5).width = 24;
  sheet.getColumn(6).width = 24;
  sheet.getColumn(7).width = 24;
  sheet.getCell("C3").value = inputs.projectName.toUpperCase();
  sheet.mergeCells("C3:G3");
  styleCell(sheet.getCell("C3"), { bold: true, color: DARK, size: 24 });
  sheet.getCell("C4").value = "Formula-linked solar PV project finance model";
  sheet.mergeCells("C4:G4");
  styleCell(sheet.getCell("C4"), { color: MID, size: 11 });
  sheet.getCell("C6").value = "Generated entirely in the browser. No project inputs were uploaded.";
  sheet.mergeCells("C6:G6");
  styleCell(sheet.getCell("C6"), { color: BLUE, bold: true, size: 9 });
  addBand(sheet, 9, "PROJECT SNAPSHOT", 7);
  const snapshot = [
    ["Installed capacity", cr("cap_mw"), PRICE, "MW"],
    ["Operating life", cr("life"), "0", "years"],
    ["PPA tariff", cr("ppa"), PRICE, "$ / MWh"],
    ["Senior debt tenor", cr("tenor"), "0", "years"],
    ["Target DSCR", cr("dscr"), MULT, "x"],
    ["Generation basis", cr("basis"), void 0, ""]
  ];
  snapshot.forEach(([label, formula, format, unit], index) => {
    const row = 10 + index;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), formula, format);
    sheet.getCell(row, 5).value = unit;
    styleCell(sheet.getCell(row, 5), { color: MID });
  });
  addBand(sheet, 18, "HEADLINE RESULTS", 7);
  const results = [
    ["Equity IRR", `Output!C6`, PCT2],
    ["Equity NPV", `Output!E6`, MONEY],
    ["Project IRR", `Output!G6`, PCT2],
    ["Senior debt", `Schedules!E${scheduleRows.draw}`, MONEY],
    ["Equity funding", `Schedules!E${scheduleRows.equity}`, MONEY],
    ["Minimum DSCR", `Output!K6`, MULT]
  ];
  results.forEach(([label, formula, format], index) => {
    const row = 19 + index;
    sheet.getCell(row, 3).value = label;
    setFormula(sheet.getCell(row, 4), formula, format);
    styleCell(sheet.getCell(row, 4), { color: BLUE, bold: true, size: 12, numFmt: format });
  });
  addBand(sheet, 27, "WORKBOOK MAP", 7);
  const map = [
    ["Control Room", "All typed assumptions. Blue-on-pale cells are safe to change."],
    ["Schedules", "Generation, revenue, operating costs, working capital, PP&E and sculpted senior debt."],
    ["FS", "Profit and loss, balance sheet, cash flow statement, FCFF and FCFE."],
    ["Output", "Returns, sources and uses, debt metrics, milestone years and integrity checks."]
  ];
  map.forEach(([name, description], index) => {
    const row = 28 + index;
    sheet.getCell(row, 3).value = name;
    sheet.getCell(row, 4).value = description;
    sheet.mergeCells(row, 4, row, 7);
    styleCell(sheet.getCell(row, 3), { bold: true, color: BLUE });
    styleCell(sheet.getCell(row, 4), { color: MID });
  });
  addBand(sheet, 34, "MODEL CONVENTIONS", 7);
  const conventions = [
    "Year 0 is a single construction period; Year 1 is the first full operating year.",
    "Debt service is sculpted to lender CFADS divided by the target DSCR; facility size is the NPV of that stream at the debt rate.",
    "The model is pre-tax by default and excludes tax equity, ITC, MACRS, DSRA, terminal value and residual value.",
    "Working capital is a funded cash reserve based on next year's opex and is released in the final year.",
    "Project IRR excludes IDC because IDC is a financing cost; project and equity NPV are shown separately."
  ];
  conventions.forEach((text, index) => {
    const row = 35 + index;
    sheet.getCell(row, 3).value = `\u2022 ${text}`;
    sheet.mergeCells(row, 3, row, 7);
    styleCell(sheet.getCell(row, 3), { color: DARK, size: 9 });
  });
  addBand(sheet, 43, "COLOUR LEGEND", 7);
  sheet.getCell("C44").value = "Typed input";
  styleCell(sheet.getCell("C44"), { fill: PALE, color: BLUE, bold: true });
  sheet.getCell("D44").value = "Blue text on a pale fill is safe to change.";
  sheet.getCell("C45").value = "Calculated";
  styleCell(sheet.getCell("C45"), { color: DARK, bold: true });
  sheet.getCell("D45").value = "Black text is formula-linked.";
  sheet.getCell("C46").value = "Memo / commentary";
  styleCell(sheet.getCell("C46"), { color: MID, italic: true });
  sheet.getCell("D46").value = "Grey italic text explains conventions and checks.";
  [44, 45, 46].forEach((row) => sheet.mergeCells(row, 4, row, 7));
  sheet.getCell("C50").value = "Generated on";
  sheet.getCell("D50").value = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  styleCell(sheet.getCell("C50"), { color: MID });
  styleCell(sheet.getCell("D50"), { color: MID });
  sheet.getCell("C52").value = "All calculated cells are formulas. Recalculation is forced when the workbook opens.";
  sheet.mergeCells("C52:G52");
  styleCell(sheet.getCell("C52"), { color: MID, italic: true, size: 8 });
  return sheet;
}
async function buildWorkbook(inputs) {
  const ExcelJS = (await import("exceljs")).default;
  const ordered = new ExcelJS.Workbook();
  ordered.creator = "Solar DSCR Model Generator";
  ordered.company = "Generated in-browser";
  ordered.created = /* @__PURE__ */ new Date();
  ordered.modified = /* @__PURE__ */ new Date();
  ordered.calcProperties.fullCalcOnLoad = true;
  const cover = ordered.addWorksheet("Cover", { properties: { tabColor: { argb: BLUE } } });
  const orderedControl = createControlRoom(ordered, inputs);
  const orderedSchedules = createSchedules(ordered, orderedControl.cr);
  const orderedFs = createFinancialStatements(ordered, orderedSchedules.rows, orderedControl.cr);
  createOutput(ordered, orderedSchedules.rows, orderedFs.rows, orderedControl.cr);
  createCover(ordered, inputs, orderedSchedules.rows, orderedFs.rows, orderedControl.cr, cover);
  const buffer = await ordered.xlsx.writeBuffer();
  return new Uint8Array(buffer);
}

// ../../../../../tmp/check-model.ts
var m = runModel(DEFAULT_INPUTS);
var y = m.years[1];
console.log(JSON.stringify({ generation: y.generation, ppaRevenue: y.ppaRevenue, opex: y.opex, cfadsLender: y.cfadsLender, debtService: y.debtService, idc: m.years[0].idc, uses: m.totalUses, debt: m.seniorDebt, equity: m.equityFunding, depr: y.depreciation, pat: y.profitAfterTax, minDscr: m.minDscr, projectIrr: m.projectIrrExcludingIdc, equityIrr: m.equityIrr, equityNpv: m.equityNpv, projectNpv: m.projectNpvAtEquityCost }, null, 2));
await writeFile("/tmp/default-solar-model.xlsx", await buildWorkbook(DEFAULT_INPUTS));
